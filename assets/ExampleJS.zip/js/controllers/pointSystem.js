'use strict';
app.controller('pointSystemController',['$scope','$rootScope','$location','environment','$localStorage','$sessionStorage','appDB','toastr','Upload',function($scope,$rootScope,$location,environment,$localStorage,$sessionStorage,appDB,toastr,Upload){
  $scope.env = environment;
  $scope. pointSystem  = function(){
    $scope.points  = [];
    var $data      = {};
    $data.StatusID = 1;
    appDB
      .callPostForm('sports/getPoints',$data) 
      .then(
          function successCallback(data)
          { 
              if(data.ResponseCode == 200)
              { 
                $scope.points = data.Data.Records;
                
              }
              if(data.ResponseCode == 500){
                var toast =   toastr.warning(data.Message, {
                                closeButton: true
                              });
                toastr.refreshTimer(toast, 5000);

              }
              if(data.ResponseCode == 501){
                var toast =   toastr.warning(data.Message, {
                                closeButton: true
                              });
                toastr.refreshTimer(toast, 5000);
              }
          },
          function errorCallback(data)
          { 
            
            if(typeof data == 'object')
            {
              var toast =  toastr.error(data.Message, {
                closeButton: true
              });
              toastr.refreshTimer(toast, 5000);
            }
      });    
  }
}]);
