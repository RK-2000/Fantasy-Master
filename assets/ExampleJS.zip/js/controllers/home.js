
app.controller('homeController',['$scope','$localStorage','$sessionStorage','$rootScope','$location','toastr','appDB','environment',function($scope,$localStorage,$sessionStorage,$rootScope,$location,toastr,appDB,environment){  
	if(!$sessionStorage.hasOwnProperty('user_details'))	{

		$scope.activeTab = 'login';
		$scope.changeTab = function(tab){
			$scope.activeTab = tab;
		}

		$scope.loginData = {};

		/*Login*/
		$scope.LoginSubmitted = false;
		$scope.signIn = function(form){
			
			var $data = {};
			$scope.helpers = Mobiweb.helpers;
	        $scope.login_error = false; 
	        $scope.login_message = ''; //login message
	        $scope.LoginSubmitted = true; 
	        if(!form.$valid)
	        {
	          return false;
		    }
		    $scope.loginData.Source 	= 'Direct';
		    $scope.loginData.DeviceType = 'Native';
	        var $data = $scope.loginData;
	        appDB
	        .callPostForm('signin',$data) 
	        .then(
	          	function successCallback(data)
	          	{ 
	
		            if(data.ResponseCode == 200)
		            { 

		                $sessionStorage.user_details = data.Data;
		                $sessionStorage.isLoggedIn = true;
		                $sessionStorage.walletBalance = data.Data.WalletAmount;
		                $scope.closePopup('loginPopup');
		                $scope.loginData = {};
		                
		                window.location.href = base_url+'matchCenter';
		            }
		            if(data.ResponseCode == 500){
		            	var toast =  toastr.warning(data.Message, {
						  	closeButton: true
						});
						toastr.refreshTimer(toast, 5000);

		            }
		            if(data.ResponseCode == 501){
		            	var toast =  toastr.warning(data.Message, {
						  	closeButton: true
						});
						toastr.refreshTimer(toast, 5000);
		            }
	          	},
	          	function errorCallback(data)
	          	{ 
	            	
	            	if(typeof data == 'object')
	            	{
	              		var toast =  toastr.error(data.Message, {
						  	closeButton: true
						});
						toastr.refreshTimer(toast, 5000);
	            	}
	          	});  

		}
		$scope.formData = {};
			
		if(getQueryStringValue('referral')){
			$scope.ReferralCode = getQueryStringValue('referral');
			$scope.activeTab = 'signup';
			// $scope.openPopup('loginPopup');
			$('#loginPopup').modal('show');
		}

		/*signUp*/
		$scope.signupSubmitted = false;
		$scope.signUp = function(form){
			
			var $data = {};
			$scope.helpers = Mobiweb.helpers;
	        $scope.signup_error = false; 
	        $scope.signup_message = ''; //login message
	        $scope.signupSubmitted = true; 
	        if(!form.$valid)
	        {
	          return false;
		    }
		    $scope.formData.UserTypeID 	= 2;
		    $scope.formData.Source 		= 'Direct';
		    $scope.formData.DeviceType	= 'Native';
		    if(getQueryStringValue('referral')){
				$scope.data = getQueryStringValue('referral');
			}
		    var data = $scope.formData;
	        appDB
	        .callPostForm('signup',data) 
	        .then(
	          	function success(data)
	          	{ 
		             
	              	if(data.ResponseCode == 200)
	            	{
		            	$scope.closePopup('loginPopup');
		            	toastr.success('Please check your email to verify account.', {
						  	closeButton: true
						});
						toastr.refreshTimer(toast, 5000);
						$scope.formData = {};
						$scope.signupSubmitted 	= false;
						$scope.LoginSubmitted 	= false;
						$scope.activeTab 		= 'login';
					} 

	              	if(data.ResponseCode == 500)
	            	{
		                var toast = toastr.warning(data.Message);
	  					toastr.refreshTimer(toast, 5000);
	              	} 

	              	if(data.ResponseCode == 501)
	            	{
		                var toast = toastr.error(data.Message);
	  					toastr.refreshTimer(toast, 5000);
	              	} 
		            
	          	},
	          	function error(data)
	          	{ 
	            	if(typeof data == 'object')
	            	{
	              		
		                var toast =  toastr.error(data.Message, {
						  	closeButton: true
						});
						toastr.refreshTimer(toast, 5000);
		              	 
	            	}
	          	});  
		}

		/* send forgot password email */
		$scope.forgotPasswordData = {};
		$scope.forgotEmailSubmitted = false;
		$scope.sendEmailForgotPassword = function(form){
			$scope.forgotEmailSubmitted = true;
			if(!form.$valid)
	        {
	          return false;
		    }
			var data = $scope.forgotPasswordData;
	        appDB
	        .callPostForm('recovery',data) 
	        .then(
	          	function success(data)
	          	{ 
		             
	              	if(data.ResponseCode == 200)
	            	{
		            	$scope.closePopup('forgotPassword');
		            	$scope.openPopup('verifyForgotPassword');
		            	toastr.success(data.Message, {
						  	closeButton: true
						});
						toastr.refreshTimer(toast, 5000);
						$scope.forgotPasswordData = {};
					} 

	              	if(data.ResponseCode == 500)
	            	{
		                var toast = toastr.warning(data.Message);
	  					toastr.refreshTimer(toast, 5000);
	              	} 

	              	if(data.ResponseCode == 501)
	            	{
		                var toast = toastr.error(data.Message);
	  					toastr.refreshTimer(toast, 5000);
	              	} 
		            
	          	},
	          	function error(data)
	          	{ 
	            	if(typeof data == 'object')
	            	{
	              		
		                var toast =  toastr.error(data.Message, {
						  	closeButton: true
						});
						toastr.refreshTimer(toast, 5000);
		              	 
	            	}
	          	});  
		}

		/* verify forgot password & create new password */
		$scope.forgotPassword = {};
		$scope.forgotPasswordSubmitted = false;
		$scope.verifyForgotPassword = function(form){
			$scope.forgotPasswordSubmitted = true;
			if(!form.$valid)
	        {
	          return false;
		    }
			var data = $scope.forgotPassword;
	        appDB
	        .callPostForm('recovery/setPassword',data) 
	        .then(
	          	function success(data)
	          	{ 
		             
	              	if(data.ResponseCode == 200)
	            	{
		            	$scope.closePopup('verifyForgotPassword');
		            	$scope.openPopup('loginPopup');
		            	toastr.success(data.Message, {
						  	closeButton: true
						});
						toastr.refreshTimer(toast, 5000);
						$scope.forgotPassword = {};
					} 

	              	if(data.ResponseCode == 500)
	            	{
		                var toast = toastr.warning(data.Message);
	  					toastr.refreshTimer(toast, 5000);
	              	} 

	              	if(data.ResponseCode == 501)
	            	{
		                var toast = toastr.error(data.Message);
	  					toastr.refreshTimer(toast, 5000);
	              	} 
		            
	          	},
	          	function error(data)
	          	{ 
	            	if(typeof data == 'object')
	            	{
	              		
		                var toast =  toastr.error(data.Message, {
						  	closeButton: true
						});
						toastr.refreshTimer(toast, 5000);
		              	 
	            	}
	          	});  
		}

		/*resend otp for account verification*/

		/*Social Login*/
		$scope.SocialLogin = function(Source){
			$rootScope.$on('event:social-sign-in-success', function(event, userDetails){
				var $data = {};
				$scope.formData = {};
			    
			    $scope.formData.UserTypeID 	= 2;
			    $scope.formData.Source 		= Source;
			    $scope.formData.SourceGIUD  = userDetails.token;
			    $scope.formData.DeviceType	= 'Native';
			    $scope.formData.FirstName	= userDetails.name;
			    $scope.formData.Email		= userDetails.email;
			    $scope.formData.ProfilePic	= userDetails.imageUrl;
		    	
			    var data = $scope.formData;
	        	console.log(data);
		        appDB
		        .callPostForm('signup',data) 
		        .then(
		          	function success(data)
		          	{ 
			             
		              	if(data.ResponseCode == 200)
		            	{
			            	$scope.closePopup('loginPopup');
			            	$sessionStorage.user_details = data.Data;
							$scope.formData = {};
							window.location.href = base_url+'matchCenter';
						} 

		              	if(data.ResponseCode == 500)
		            	{
			                var toast = toastr.warning(data.Message);
		  					toastr.refreshTimer(toast, 5000);
		              	} 

		              	if(data.ResponseCode == 501)
		            	{
			                var toast = toastr.error(data.Message);
		  					toastr.refreshTimer(toast, 5000);
		              	} 
			            
		          	},
		          	function error(data)
		          	{ 
		            	if(typeof data == 'object')
		            	{
		              		
			                var toast =  toastr.error(data.Message, {
							  	closeButton: true
							});
							toastr.refreshTimer(toast, 5000);
			              	 
		            	}
		          	});  
			});
		}
	}
	else{
		window.location.href = base_url+'matchCenter';
	}
}]);