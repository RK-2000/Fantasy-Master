'use strict';

app.controller('myAccountController',['$scope','$rootScope','$location','environment','$localStorage','$sessionStorage','appDB','toastr',function($scope,$rootScope,$location,environment,$localStorage,$sessionStorage,appDB,toastr){
  $scope.env = environment;
  if($sessionStorage.hasOwnProperty('user_details') && $sessionStorage.isLoggedIn==true){
  	//do something
  	
    $scope.activeTab  = 'transaction';
    $scope.ChangeTab = function(tab){
      $scope.activeTab  = tab;
    }

    $scope.accountDetails = {};
    var $data             = {};
    $scope.getAccountInfo = function(TransactionMode){
    	
      $scope.transactions  = [];
    	$data.UserGUID             = $sessionStorage.user_details.UserGUID;
    	$data.SessionKey           = $sessionStorage.user_details.SessionKey;
      $data.Params               = "Amount,CurrencyPaymentGateway,TransactionType,TransactionID,Status,Narration,OpeningBalance,ClosingBalance,EntryDate,WalletAmount,WinningAmount,CashBonus,TotalCash";
    	$data.TransactionMode      = TransactionMode;
    	appDB
      .callPostForm('wallet/getWallet',$data) 
      .then(
        	function successCallback(data)
        	{ 
              
              if(data.ResponseCode == 200)
              { 

                  $scope.accountDetails = data.Data;
                  $scope.transactions = data.Data.Records;

                  console.log($scope.accountDetails,' ',$scope.transactions)
              }
              if(data.ResponseCode == 500){
              	var toast =  toastr.warning(data.Message, {
  				  	closeButton: true
  				});
  				toastr.refreshTimer(toast, 5000);

              }
              if(data.ResponseCode == 501){
              	var toast =  toastr.warning(data.Message, {
  				  	closeButton: true
  				});
  				toastr.refreshTimer(toast, 5000);
              }
        	},
        	function errorCallback(data)
        	{ 
          	
          	if(typeof data == 'object')
          	{
            		var toast =  toastr.error(data.Message, {
  				  	closeButton: true
  				});
  				toastr.refreshTimer(toast, 5000);
          	}
    	});  

    }

    $scope.submitted = false;
    $scope.getTransactions = function(TransactionMode){
      
      console.log(TransactionMode);
      $data.FromDate            = $scope.FromDate;
      $data.ToDate              = $scope.ToDate;
      $data.TransactionType     = $scope.TransactionType;

      $scope.getAccountInfo(TransactionMode);

    }
    //$scope.getWalletDetails
    $scope.withdrawSubmitted = false;
    $rootScope.withdrawRequest = function(form,amount){
      $scope.helpers = Mobiweb.helpers;
      $scope.withdrawSubmitted = true;
      if(!form.$valid)
      {
        return false;
      }
      var $data = {};
      $data.PaymentGateway = 'Bank';
      $data.Amount = amount;
      $data.SessionKey = $sessionStorage.user_details.SessionKey;
      $data.UserGUID   = $sessionStorage.user_details.UserGUID;
      appDB
      .callPostForm('wallet/withdrawal',$data) 
      .then(
          function successCallback(data)
          { 
              
              if(data.ResponseCode == 200)
              { 
                var toast =  toastr.success(data.Message, {
                    closeButton: true
                });
                toastr.refreshTimer(toast, 5000); 
                $scope.getWalletDetails();
                $scope.closePopup('withdrawPopup');
              }
              if(data.ResponseCode == 500){
                    var toast =  toastr.warning(data.Message, {
                  closeButton: true
              });
              toastr.refreshTimer(toast, 5000);

              }
              if(data.ResponseCode == 501){
                      var toast =  toastr.warning(data.Message, {
                    closeButton: true
                });
                toastr.refreshTimer(toast, 5000);
              }
          },
          function errorCallback(data)
          { 
            
            if(typeof data == 'object')
            {
                var toast =  toastr.error(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);
            }
      });  

    }

  }else
  {
  	window.location.href = base_url;
  }
}]);
