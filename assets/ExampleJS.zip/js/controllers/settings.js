'use strict';
app.controller('settingsController',['$scope','$rootScope','$location','environment','$localStorage','$sessionStorage','appDB','toastr','Upload',function($scope,$rootScope,$location,environment,$localStorage,$sessionStorage,appDB,toastr,Upload){
  $scope.env = environment;

  if($sessionStorage.hasOwnProperty('user_details') && $sessionStorage.isLoggedIn==true){
  	$scope.user_details = $sessionStorage.user_details;
  	$scope.isLoggedIn = $sessionStorage.isLoggedIn;
    
    $scope.profileDetails = {};
    $scope.panDetails     = {};
    $scope.bankDetails    = {};

    $scope.getProfileInfo = function(){
      
      var $data = {};
      $data.UserGUID = $sessionStorage.user_details.UserGUID;
      $data.SessionKey = $sessionStorage.user_details.SessionKey;
      $data.Params     = 'UserTypeID,UserTypeName,FirstName, MiddleName, LastName, Email, Username, Gender, BirthDate, CountryCode, CountryName, CityName, StateName, PhoneNumber,Address,MediaPAN,MediaBANK,PanStatus,BankStatus';
      appDB
      .callPostForm('users/getProfile',$data) 
      .then(
          function successCallback(data)
          { 
              
              if(data.ResponseCode == 200)
              { 

                  $scope.profileDetails = data.Data;
                  
                  if($scope.profileDetails.hasOwnProperty('PhoneNumber')){
                    $sessionStorage.user_details.PhoneNumber = $scope.profileDetails.PhoneNumber;
                  }else{
                    $sessionStorage.user_details.PhoneNumber = '';
                  }
                  
                    $scope.panDetails = JSON.parse($scope.profileDetails.MediaPAN.MediaCaption);  
                    
                    $scope.bankDetails = JSON.parse($scope.profileDetails.MediaBANK.MediaCaption);
                  
              }
              if(data.ResponseCode == 500){
                var toast =  toastr.warning(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);

              }
              if(data.ResponseCode == 501){
                var toast =  toastr.warning(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);
              }
          },
          function errorCallback(data)
          { 
            
            if(typeof data == 'object')
            {
                var toast =  toastr.error(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);
            }
      });  

    }    
    $scope.getProfileInfo();
    $scope.isOtpSend = false; //to manage otp screen

    $scope.activeMenu = 'verification';
    $scope.activateTab = function(tab){
      $scope.activeMenu = tab;  
    }
  
    $scope.submitted = false;
    
    /*function to update phone number and send OTP for mobile verification*/

    $scope.updateMobileNumber = function(form){
      var $data = {};
      $scope.helpers = Mobiweb.helpers;
      $scope.submitted = true; 
      if(!form.$valid)
      {
        return false;
      }
      // if($scope.profileDetails.PhoneNumber == $sessionStorage.user_details.PhoneNumber){
      //   $scope.verifyMobileForm.mobile.$error.oldNumber = 'Phone number should not be same.';
      //   return false;
      // }
      $data.PhoneNumber = $scope.profileDetails.PhoneNumber;
      $data.SessionKey = $sessionStorage.user_details.SessionKey;
      
      appDB
      .callPostForm('users/updateUserInfo',$data) 
      .then(
          function successCallback(data)
          { 
              if(data.ResponseCode == 200)
              { 
                $scope.profileDetails = data.Data;
                $scope.isOtpSend = true;
                $scope.submitted = false; 
                var toast =  toastr.success('OTP sent to you mobile number', {
                      closeButton: true
                });
                toastr.refreshTimer(toast, 5000);
              }
              if(data.ResponseCode == 500){
                var toast =  toastr.warning(data.Message, {
                closeButton: true
          });
          toastr.refreshTimer(toast, 5000);

              }
              if(data.ResponseCode == 501){
                var toast =  toastr.warning(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);
              }
          },
          function errorCallback(data)
          { 
            
            if(typeof data == 'object')
            {
              var toast =  toastr.error(data.Message, {
                closeButton: true
              });
              toastr.refreshTimer(toast, 5000);
            }
      });    
    }

    /*function to verify mobile number*/
    $scope.otpSubmitted = false;
    $scope.verifyMobileNumber = function(form){
     
      var $data = {};
      $scope.helpers = Mobiweb.helpers;
      $scope.otpSubmitted = true; 
      if(!form.$valid)
      {
        return false;
      }
      console.log($data);
      $data.OTP = $scope.OTP;
      $data.SessionKey = $sessionStorage.user_details.SessionKey;
      
      appDB
      .callPostForm('signup/verifyPhoneNumber',$data) 
      .then(
          function successCallback(data)
          { 
              if(data.ResponseCode == 200)
              { 
                //$scope.profileDetails = data.Data;
                $scope.isOtpSend = false;
                $scope.otpSubmitted = false;
                var toast =  toastr.warning(data.Message, {
                      closeButton: true
                });
                toastr.refreshTimer(toast, 5000);
              }
              if(data.ResponseCode == 500){
                var toast =  toastr.warning(data.Message, {
                closeButton: true
          });
          toastr.refreshTimer(toast, 5000);

              }
              if(data.ResponseCode == 501){
                var toast =  toastr.warning(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);
              }
          },
          function errorCallback(data)
          { 
            
            if(typeof data == 'object')
            {
              var toast =  toastr.error(data.Message, {
                closeButton: true
              });
              toastr.refreshTimer(toast, 5000);
            }
      });    
    }

    /*PAN upload*/
    //uploadPanCardDetails
    $scope.panSubmitted = false;
    $scope.uploadPanCardDetails = function(form,files){
    
      $scope.panSubmitted = true;
      $scope.helpers = Mobiweb.helpers;
      if(!form.$valid)
      {
        return false;
      }
      if (files != null) {

      var fd = new FormData();
      fd.append('SessionKey',$sessionStorage.user_details.SessionKey);
      fd.append('File', files);
      fd.append('Section', 'PAN');
      fd.append('MediaCaption', JSON.stringify($scope.panDetails));
      appDB
       .callPostImage('upload/image',fd) 
       .then(
          function success(data){ 
          
           if(data.ResponseCode == 200 ){ 
              var toast =  toastr.success(data.Message, {
                closeButton: true
              });
              toastr.refreshTimer(toast, 5000);
              setTimeout(function(){ 
                window.location.reload();
              }, 3000);
              
            } 
          },
          function error(data){ 
           $scope.errorMsg = data.message; 
          }
        );

      }
    }

    /*Bank upload*/
    $scope.bankDetailsForm = false;
    $scope.uploadBankDetail = function(form,files){
     
      $scope.bankDetailsForm = true;
      $scope.helpers = Mobiweb.helpers;
      if(!form.$valid)
      {
        return false;
      }
      if (files != null) {
        var fd = new FormData();
        fd.append('SessionKey',$sessionStorage.user_details.SessionKey);
        fd.append('File', files);
        fd.append('Section', 'BankDetail');
        fd.append('MediaCaption', JSON.stringify($scope.bankDetails));
        appDB
         .callPostImage('upload/image',fd) 
         .then(
            function success(data){ 
             
             if(data.ResponseCode == 200 ){ 
                var toast =  toastr.success(data.Message, {
                  closeButton: true
                });
                toastr.refreshTimer(toast, 5000);
                $scope.bankDetailsForm = false;
                setTimeout(function(){ 
                  window.location.reload();
                }, 3000);
              } 
            },
            function error(data){ 
             $scope.errorMsg = data.message; 
            }
          );

      }
    }

    $scope.countryList = [];
    $scope.getCountryList = function(){
      
      var $data = {};
      appDB
      .callPostForm('utilities/getCountries',$data) 
      .then(
          function successCallback(data)
          { 
              
              if(data.ResponseCode == 200)
              { 

                  $scope.countryList = data.Data;
                  
              }
              if(data.ResponseCode == 500){
                var toast =  toastr.warning(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);

              }
              if(data.ResponseCode == 501){
                var toast =  toastr.warning(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);
              }
          },
          function errorCallback(data)
          { 
            
            if(typeof data == 'object')
            {
                var toast =  toastr.error(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);
            }
      }); 
    }
  }
  else{
    window.location.href = base_url;
  }



  
}]);
