'use strict';
app.filter('cut', function () {
    return function (value, wordwise, max, tail) {
        if (!value) return '';

        max = parseInt(max, 10);
        if (!max) return value;
        if (value.length <= max) return value;

        value = value.substr(0, max);
        if (wordwise) {
            var lastspace = value.lastIndexOf(' ');
            if (lastspace !== -1) {
              //Also remove . and , so its gives a cleaner result.
              if (value.charAt(lastspace-1) === '.' || value.charAt(lastspace-1) === ',') {
                lastspace = lastspace - 1;
              }
              value = value.substr(0, lastspace);
            }
        }

        return value + (tail || ' …');
    };
});
app.controller('createTeamController', ['$scope', '$rootScope', '$location', 'environment', '$localStorage', '$sessionStorage', 'appDB', 'toastr', function($scope, $rootScope, $location, environment, $localStorage, $sessionStorage, appDB, toastr) {
    $scope.env = environment;
    $scope.data.pageSize = 15;
    $scope.data.pageNo = 1;
    $scope.coreLogic = Mobiweb.helpers;
    $rootScope.selectedPlayers = []; // selected players array
    $rootScope.Captain      = ''; // selected Captain
    $rootScope.ViceCaptain  = ''; // selected Vice Captain
    $rootScope.MatchGUID = getQueryStringValue('MatchGUID'); //Match GUID
    $rootScope.selectedCaptain = ''; //selected captain name
    $rootScope.selectedViceCaptain = ''; //selected vice captain name
    
    $scope.totalCredits = parseFloat(100).toFixed(2);
    $scope.leftCredits  = parseFloat(100).toFixed(2);

    /*Function to get mactch center details*/
    $scope.MatchesDetail = {};
    $scope.matchCenterDetails = function() {

        var $data = {};
        $data.MatchGUID = getQueryStringValue('MatchGUID'); //   Match GUID
        $rootScope.MatchGUID = getQueryStringValue('MatchGUID'); //   Match GUID
        $data.Params = 'SeriesName,MatchType,MatchNo,MatchStartDateTime,TeamNameLocal,TeamNameVisitor,TeamNameShortLocal,TeamNameShortVisitor,TeamFlagLocal,TeamFlagVisitor,MatchLocation,SeriesGUID,Status';
        appDB
            .callPostForm('sports/getMatch', $data)
            .then(
                function successCallback(data) {
                    if (data.ResponseCode == 200) {
                        $scope.MatchesDetail = data.Data;
                        $rootScope.CurrentSelectedMatchDetail = data.Data;
                    }
                    if (data.ResponseCode == 500) {
                        var toast = toastr.warning(data.Message, {
                            closeButton: true
                        });
                        toastr.refreshTimer(toast, 5000);
                    }
                    if (data.ResponseCode == 501) {
                        var toast = toastr.warning(data.Message, {
                            closeButton: true
                        });
                        toastr.refreshTimer(toast, 5000);
                    }
                },
                function errorCallback(data) {

                    if (typeof data == 'object') {
                        var toast = toastr.error(data.Message, {
                            closeButton: true
                        });
                        toastr.refreshTimer(toast, 5000);
                    }
                });
    }
    /*
    Description : To get user created team list
    */
    $rootScope.userTeams = [];
    $scope.UsersTeamList = function() {
        var $data = {};
        $rootScope.userTeams = []; //user team list array
        $data.SessionKey = $sessionStorage.user_details.SessionKey; //user session key
        $data.MatchGUID = getQueryStringValue('MatchGUID'); //Match GUID
        $data.Params = 'UserTeamName';
        $data.PageNo = 0;

        appDB
            .callPostForm('contest/getUserTeams', $data)
            .then(
                function successCallback(data) {
                    if (data.ResponseCode == 200) {
                        if(data.Data.hasOwnProperty('Records')){
                            $rootScope.userTeams = data.Data;
                           
                        }
                        else{
                            $rootScope.userTeams = [];
                            
                        }
                        $scope.UserTeamsTotalCount = data.Data.TotalRecords;
                    } else {
                        $scope.data.noRecords = true;
                    }
                    if (data.ResponseCode == 500) {
                        var toast = toastr.warning(data.Message, {
                            closeButton: true
                        });
                        toastr.refreshTimer(toast, 5000);
                        $scope.data.noRecords = true;
                    }
                    if (data.ResponseCode == 501) {
                        var toast = toastr.warning(data.Message, {
                            closeButton: true
                        });
                        toastr.refreshTimer(toast, 5000);
                        $scope.data.noRecords = true;
                    }
                },
                function errorCallback(data) {

                    if (typeof data == 'object') {
                        var toast = toastr.error(data.Message, {
                            closeButton: true
                        });
                        toastr.refreshTimer(toast, 5000);
                        $scope.data.noRecords = true;
                    }
                });

    }
    if ($sessionStorage.hasOwnProperty('user_details') && $sessionStorage.isLoggedIn == true) {
        $scope.user_details = $sessionStorage.user_details;

        /*get url params*/
        if (!getQueryStringValue('MatchGUID')) {
            window.location.href = 'matchCenter';
        } else {
            $scope.activeTab = 'wk';

            $scope.teamStructure = {
                "WicketKeeper": {
                    "min": 1,
                    "max": 1,
                    "occupied": 0,
                    player: [],
                    "icon": "flaticon1-pair-of-gloves"
                },
                "Batsman": {
                    "min": 3,
                    "max": 5,
                    "occupied": 0,
                    player: [],
                    "icon": "flaticon1-ball"
                },
                "Bowler": {
                    "min": 3,
                    "max": 5,
                    "occupied": 0,
                    player: [],
                    "icon": "flaticon1-tennis-ball"
                },
                "AllRounder": {
                    "min": 1,
                    "max": 3,
                    "occupied": 0,
                    player: [],
                    "icon": "flaticon1-ball"
                },
                "Extra": {
                    "min": 3,
                    "max": 3,
                    occupied: 0,
                    player: []
                },
                "ready": false
            };
            $scope.resetTeamStructure = function() {
                $scope.teamStructure = {
                    "WicketKeeper": {
                        "min": 1,
                        "max": 1,
                        "occupied": 0,
                        player: [],
                        "icon": "flaticon1-pair-of-gloves"
                    },
                    "Batsman": {
                        "min": 3,
                        "max": 5,
                        "occupied": 0,
                        player: [],
                        "icon": "flaticon1-ball"
                    },
                    "Bowler": {
                        "min": 3,
                        "max": 5,
                        "occupied": 0,
                        player: [],
                        "icon": "flaticon1-tennis-ball"
                    },
                    "AllRounder": {
                        "min": 1,
                        "max": 3,
                        "occupied": 0,
                        player: [],
                        "icon": "flaticon1-ball"
                    },
                    "Extra": {
                        "min": 3,
                        "max": 3,
                        occupied: 0,
                        player: []
                    },
                    "ready": false
                };
                $scope.teamCount = 0 ;
                $scope.totalCredits = parseFloat(100).toFixed(2);
                $scope.leftCredits  = parseFloat(100).toFixed(2);
                $scope.players.map(function(player) {
                                    player.IsAdded = false;
                                    // player.Position = "Player";
                                    player.PlayerPosition = "Player";
                                    return player;
                                });
            }
            $scope.teamCount = 0 ; //default team count
            $scope.gotoTab = function(tab) {
                $scope.activeTab = tab;
            }

            /*
              Description : To get Team players
            */
            $scope.MatchPlayers = function() {
                $scope.players = [];
                var $data = {};
                $data.MatchGUID = getQueryStringValue('MatchGUID'); //   Match GUID
                $data.Params = 'PlayerRole,PlayerPic,PlayerCountry,PlayerBornPlace,PlayerBattingStyle,PlayerBowlingStyle,MatchType,MatchNo,MatchDateTime,SeriesName,TeamGUID,PlayerBattingStats,PlayerBowlingStats,IsPlaying,PointsData,PlayerSalary';
                $data.pageNo = 0;
                appDB
                    .callPostForm('sports/getPlayers', $data)
                    .then(
                        function successCallback(data) {
                            if (data.ResponseCode == 200) {
                                $scope.players = data.Data.Records;
                                if(data.Data.TotalRecords > 0){
                                    if($scope.MatchesDetail.MatchType.includes('T20')){
                                        angular.forEach($scope.players,function(value,key){
                                            value.Salary = (!value.PlayerSalary.T20Credits) ? 0.00 : value.PlayerSalary.T20Credits ;
                                        });
                                    }
                                    else if($scope.MatchesDetail.MatchType.includes('T20i')){
                                        angular.forEach($scope.players,function(value,key){
                                            value.Salary = (!value.PlayerSalary.T20iCredits!='') ? 0.00 : value.PlayerSalary.T20iCredits ;
                                         });
                                    }
                                    else if($scope.MatchesDetail.MatchType.includes('ODI')){
                                        angular.forEach($scope.players,function(value,key){
                                            value.Salary = (!value.PlayerSalary.ODICredits) ? 0.00 : value.PlayerSalary.ODICredits ;
                                        });
                                    }
                                    else if($scope.MatchesDetail.MatchType.includes('Test')){
                                        angular.forEach($scope.players,function(value,key){
                                            value.Salary = (!value.PlayerSalary.TestCredits) ? 0.00 : value.PlayerSalary.TestCredits ;
                                        });
                                    }
                                    else{
                                        angular.forEach($scope.players,function(value,key){
                                            value.Salary = (!value.PlayerSalary.T20Credits) ? 0.00 : value.PlayerSalary.T20Credits ;
                                        });
                                    }


                                    $scope.addresses = $scope.players.map(function(player) {
                                        player.IsAdded = false;
                                        player.PlayerPosition = "Player";
                                        return player;
                                    });
                                }
                               
                            }
                            if (data.ResponseCode == 500) {
                                var toast = toastr.warning(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                            }
                            if (data.ResponseCode == 501) {
                                var toast = toastr.warning(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                            }
                        },
                        function errorCallback(data) {

                            if (typeof data == 'object') {
                                var toast = toastr.error(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                            }
                        });
            }

            /*
              Description : To add Player 
            */

            $scope.addRemovePlayer = function(PlayerGUID,isAdded,playerDetails) {
                if (!isAdded) {
                    //to add player from team 
                    for (var i in $scope.players) {
                        if ($scope.players[i].PlayerGUID == PlayerGUID && playerDetails.TeamID == $scope.players[i].TeamID) {
                            if (isAdded == false) {
                                if($scope.teamStructure['Batsman'].occupied + $scope.teamStructure['WicketKeeper'].occupied + $scope.teamStructure['AllRounder'].occupied + $scope.teamStructure['Bowler'].occupied  == 11){
                                    var toast = toastr.error('You cannot add more than 11 players', {
                                                    closeButton: true
                                                });
                                    toastr.refreshTimer(toast, 5000);
                                    return false;
                                }else{
                                    if (playerDetails.PlayerRole == 'WicketKeeper') {
                                        
                                        if(parseFloat($scope.leftCredits) < parseFloat(playerDetails.Salary)){
                                            var toast = toastr.error('Insufficient credit.', {
                                                    closeButton: true
                                                });
                                            toastr.refreshTimer(toast, 5000);
                                        }else{
                                            if ($scope.teamStructure[playerDetails.PlayerRole].max > $scope.teamStructure[playerDetails.PlayerRole].occupied) {
                                                $scope.teamStructure[playerDetails.PlayerRole].player.push({'PlayerGUID':playerDetails.PlayerGUID,'PlayerPosition':playerDetails.PlayerPosition,'PlayerName':playerDetails.PlayerName,'PlayerPic':playerDetails.PlayerPic,'PlayerSalary':playerDetails.Salary});
                                                $scope.teamStructure[playerDetails.PlayerRole].occupied++;
                                                $scope.players[i].IsAdded = true;
                                                $rootScope.selectedPlayers.push({'PlayerGUID':playerDetails.PlayerGUID,'PlayerName' : playerDetails.PlayerName,'PlayerPic' : playerDetails.PlayerPic,'PlayerPosition':playerDetails.PlayerPosition,'PlayerSalary':playerDetails.Salary});

                                                $scope.leftCredits = parseFloat($scope.leftCredits).toFixed(2) - parseFloat(playerDetails.Salary).toFixed(2);

                                            } else {
                                                var toast = toastr.error('You cannot add more than ' + $scope.teamStructure[playerDetails.PlayerRole].max + ' ' + playerDetails.PlayerRole, {
                                                    closeButton: true
                                                });
                                                toastr.refreshTimer(toast, 5000);
                                            }
                                        }
                                    }
                                    if (playerDetails.PlayerRole == 'Batsman') {
                                        if(parseFloat($scope.leftCredits) < parseFloat(playerDetails.Salary)){
                                            var toast = toastr.error('Insufficient credit.', {
                                                    closeButton: true
                                                });
                                            toastr.refreshTimer(toast, 5000);
                                        }
                                        else{
                                            if($scope.teamCount == 10 &&  $scope.teamStructure['WicketKeeper'].occupied == 0){
                                                var toast = toastr.error('Minimum '+$scope.teamStructure['WicketKeeper'].min+' WicketKeeper required in team.', {
                                                              closeButton: true
                                                            });
                                                toastr.refreshTimer(toast, 5000);
                                                return false;
                                            }
                                            else if($scope.teamCount == 9 &&  $scope.teamStructure['AllRounder'].occupied == 0){
                                                var toast = toastr.error('Minimum '+$scope.teamStructure['AllRounder'].min+' All-Rounder required in team.', {
                                                              closeButton: true
                                                            });
                                                toastr.refreshTimer(toast, 5000);
                                                return false;
                                            }
                                            else if($scope.teamStructure[playerDetails.PlayerRole].max > $scope.teamStructure[playerDetails.PlayerRole].occupied) {
                                                $scope.teamStructure[playerDetails.PlayerRole].player.push({'PlayerGUID':playerDetails.PlayerGUID,'PlayerPosition':playerDetails.PlayerPosition,'PlayerName':playerDetails.PlayerName,'PlayerPic':playerDetails.PlayerPic,'PlayerSalary':playerDetails.Salary});
                                                $scope.teamStructure[playerDetails.PlayerRole].occupied++;
                                                $scope.players[i].IsAdded = true;
                                                $rootScope.selectedPlayers.push({'PlayerGUID':playerDetails.PlayerGUID,'PlayerName' : playerDetails.PlayerName,'PlayerPic' : playerDetails.PlayerPic,'PlayerPosition':playerDetails.PlayerPosition,'PlayerSalary':playerDetails.Salary});
                                                $scope.leftCredits = parseFloat($scope.leftCredits).toFixed(2) - parseFloat(playerDetails.Salary).toFixed(2);
                                            } else {
                                                var toast = toastr.error('You cannot add more than ' + $scope.teamStructure[playerDetails.PlayerRole].max + ' ' + playerDetails.PlayerRole, {
                                                    closeButton: true
                                                });
                                                toastr.refreshTimer(toast, 5000);
                                            }
                                        }
                                    }
                                    if (playerDetails.PlayerRole == 'Bowler') {
                                        if(parseFloat($scope.leftCredits) < parseFloat(playerDetails.Salary)){
                                            var toast = toastr.error('Insufficient credit.', {
                                                    closeButton: true
                                                });
                                            toastr.refreshTimer(toast, 5000);
                                        }else{
                                            if($scope.teamCount == 10 &&  $scope.teamStructure['WicketKeeper'].occupied == 0){
                                                var toast = toastr.error('Minimum '+$scope.teamStructure['WicketKeeper'].min+' WicketKeeper required in team.', {
                                                              closeButton: true
                                                            });
                                                toastr.refreshTimer(toast, 5000);
                                                return false;
                                            }
                                            else if($scope.teamCount == 9 &&  $scope.teamStructure['AllRounder'].occupied == 0){
                                                var toast = toastr.error('Minimum '+$scope.teamStructure['AllRounder'].min+' All-Rounder required in team.', {
                                                              closeButton: true
                                                            });
                                                toastr.refreshTimer(toast, 5000);
                                                return false;
                                            }
                                            else if ($scope.teamStructure[playerDetails.PlayerRole].max > $scope.teamStructure[playerDetails.PlayerRole].occupied) {
                                                
                                                $scope.teamStructure[playerDetails.PlayerRole].player.push({'PlayerGUID':playerDetails.PlayerGUID,'PlayerPosition':playerDetails.PlayerPosition,'PlayerName':playerDetails.PlayerName,'PlayerPic':playerDetails.PlayerPic,'PlayerSalary':playerDetails.Salary});
                                                $scope.teamStructure[playerDetails.PlayerRole].occupied++;
                                                $scope.players[i].IsAdded = true;
                                                $rootScope.selectedPlayers.push({'PlayerGUID':playerDetails.PlayerGUID,'PlayerName' : playerDetails.PlayerName,'PlayerPic' : playerDetails.PlayerPic,'PlayerPosition':playerDetails.PlayerPosition,'PlayerSalary':playerDetails.Salary});
                                                $scope.leftCredits = parseFloat($scope.leftCredits).toFixed(2) - parseFloat(playerDetails.Salary).toFixed(2);
                                            } else {
                                                var toast = toastr.error('You cannot add more than ' + $scope.teamStructure[playerDetails.PlayerRole].max + ' ' + playerDetails.PlayerRole, {
                                                  closeButton: true
                                                });
                                                toastr.refreshTimer(toast, 5000);
                                            }
                                        }
                                    }
                                    if (playerDetails.PlayerRole == 'AllRounder') {
                                        if(parseFloat($scope.leftCredits) < parseFloat(playerDetails.Salary)){
                                            var toast = toastr.error('Insufficient credit.', {
                                                    closeButton: true
                                                });
                                            toastr.refreshTimer(toast, 5000);
                                        }else{

                                            if($scope.teamCount == 10 &&  $scope.teamStructure['WicketKeeper'].occupied == 0){
                                                var toast = toastr.error('Minimum '+$scope.teamStructure['WicketKeeper'].min+' WicketKeeper required in team.', {
                                                              closeButton: true
                                                            });
                                                toastr.refreshTimer(toast, 5000);
                                                return false;
                                            }
                                            else if ($scope.teamStructure[playerDetails.PlayerRole].max > $scope.teamStructure[playerDetails.PlayerRole].occupied) {
                                                if ($scope.teamStructure['Batsman'].occupied + $scope.teamStructure['WicketKeeper'].occupied + $scope.teamStructure['AllRounder'].occupied > 7) {
                                                    var toast = toastr.error('Please select atleast ' + $scope.teamStructure['Bowler'].min + ' bowler.', {
                                                        closeButton: true
                                                    });
                                                    toastr.refreshTimer(toast, 5000);
                                                    return false;
                                                } else {
                                                    $scope.teamStructure[playerDetails.PlayerRole].player.push({'PlayerGUID':playerDetails.PlayerGUID,'PlayerPosition':playerDetails.PlayerPosition,'PlayerName':playerDetails.PlayerName,'PlayerPic':playerDetails.PlayerPic,'PlayerSalary':playerDetails.Salary});
                                                    $scope.teamStructure[playerDetails.PlayerRole].occupied++;
                                                    $scope.players[i].IsAdded = true;
                                                    $rootScope.selectedPlayers.push({'PlayerGUID':playerDetails.PlayerGUID,'PlayerName' : playerDetails.PlayerName,'PlayerPic' : playerDetails.PlayerPic,'PlayerPosition':playerDetails.PlayerPosition,'PlayerSalary':playerDetails.Salary});
                                                    $scope.leftCredits = parseFloat($scope.leftCredits).toFixed(2) - parseFloat(playerDetails.Salary).toFixed(2);
                                                }
                                            } else {
                                                var toast = toastr.error('You cannot add more than ' + $scope.teamStructure[playerDetails.PlayerRole].max + ' ' + playerDetails.PlayerRole, {
                                                    closeButton: true
                                                });
                                                toastr.refreshTimer(toast, 5000);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    $scope.teamCount = $scope.teamStructure['AllRounder'].occupied + $scope.teamStructure['Bowler'].occupied + $scope.teamStructure['Batsman'].occupied + $scope.teamStructure['WicketKeeper'].occupied;
                    
                    if($scope.teamCount==11){
                        $scope.openPopup('selectCaptainViceCaptainModal');
                    }
                } else {
                    //to remove player from team
                    
                    if (playerDetails.PlayerRole == 'WicketKeeper') {

                      if ($scope.teamStructure[playerDetails.PlayerRole].occupied > 0) {
                          $scope.teamStructure[playerDetails.PlayerRole].player.splice(0);
                          $scope.leftCredits = (parseFloat($scope.leftCredits)+parseFloat(playerDetails.Salary)).toFixed(2);
                          $scope.teamStructure[playerDetails.PlayerRole].occupied--;
                          for (var i in $scope.players) {
                            if($scope.players[i].PlayerGUID == playerDetails.PlayerGUID){
                              $scope.players[i].IsAdded = false;
                            }
                          }
                      } 
                    }
                    if (playerDetails.PlayerRole == 'Batsman') {
                      if ($scope.teamStructure[playerDetails.PlayerRole].occupied > 0) {
                        for(let j=0; j < $scope.teamStructure[playerDetails.PlayerRole].occupied;j++){
                          if($scope.teamStructure[playerDetails.PlayerRole].player[j].PlayerGUID == playerDetails.PlayerGUID){
                            $scope.teamStructure[playerDetails.PlayerRole].player.splice(j);
                            $scope.leftCredits = (parseFloat($scope.leftCredits)+parseFloat(playerDetails.Salary)).toFixed(2);
                            $scope.teamStructure[playerDetails.PlayerRole].occupied--;
                            for (var i in $scope.players) {
                              if($scope.players[i].PlayerGUID == playerDetails.PlayerGUID){
                                $scope.players[i].IsAdded = false;
                              }
                            }
                          }
                        }
                      }
                    }
                    if (playerDetails.PlayerRole == 'Bowler') {
                      if ($scope.teamStructure[playerDetails.PlayerRole].occupied > 0) {
                        for(let j=0; j < $scope.teamStructure[playerDetails.PlayerRole].occupied;j++){
                          if($scope.teamStructure[playerDetails.PlayerRole].player[j].PlayerGUID == playerDetails.PlayerGUID){
                            $scope.teamStructure[playerDetails.PlayerRole].player.splice(j);
                            $scope.leftCredits = (parseFloat($scope.leftCredits)+parseFloat(playerDetails.Salary)).toFixed(2);
                            $scope.teamStructure[playerDetails.PlayerRole].occupied--;
                            for (var i in $scope.players) {
                              if($scope.players[i].PlayerGUID == playerDetails.PlayerGUID){
                                $scope.players[i].IsAdded = false;
                              }
                            }
                          }
                        }
                      }
                    }
                    if (playerDetails.PlayerRole == 'AllRounder') {
                      if ($scope.teamStructure[playerDetails.PlayerRole].occupied > 0) {
                        for(let j=0 ; j < $scope.teamStructure[playerDetails.PlayerRole].occupied; j++){
                          if($scope.teamStructure[playerDetails.PlayerRole].player[j].PlayerGUID == playerDetails.PlayerGUID){
                            $scope.teamStructure[playerDetails.PlayerRole].player.splice(j);
                            $scope.leftCredits = (parseFloat($scope.leftCredits)+parseFloat(playerDetails.Salary)).toFixed(2);
                            $scope.teamStructure[playerDetails.PlayerRole].occupied--;
                            for (var i in $scope.players) {
                              if($scope.players[i].PlayerGUID == playerDetails.PlayerGUID){
                                $scope.players[i].IsAdded = false;
                              }
                            }
                          }
                        }
                      }
                    }
                    $scope.teamCount = $scope.teamStructure['AllRounder'].occupied + $scope.teamStructure['Bowler'].occupied + $scope.teamStructure['Batsman'].occupied + $scope.teamStructure['WicketKeeper'].occupied;
                    angular.forEach($rootScope.selectedPlayers,function(val,key){
                        if(val.PlayerGUID == playerDetails.PlayerGUID){
                            $rootScope.selectedPlayers.splice(key);
                        } 
                    });
                    
                }
              
            }
        }

        /*
            Description : To Select captain
        */

        $rootScope.selectCaptain = function(PlayerGUID){
            
            for(var i = 0; i < $rootScope.selectedPlayers.length; i++){
                if($rootScope.selectedPlayers[i].PlayerGUID == PlayerGUID){
                    $rootScope.selectedPlayers[i].PlayerPosition  = 'Captain';
                    $rootScope.selectedCaptain = $rootScope.selectedPlayers[i].PlayerName;
                }
            }
        }

        /*
            Description : To Select vice captain
        */

        $rootScope.selectViceCaptain = function(PlayerGUID){
           
            for(var i = 0; i < $rootScope.selectedPlayers.length; i++){
                if($rootScope.selectedPlayers[i].PlayerGUID == PlayerGUID){
                    $rootScope.selectedPlayers[i].PlayerPosition  = 'ViceCaptain';
                    $rootScope.selectedViceCaptain = $rootScope.selectedPlayers[i].PlayerName;
                }
            }
        }

         /*
            Description : To join Contest after Team Create
        */

        $rootScope.JoinContest = function(){
            var $data              = {};
            $data.ContestGIUD      = $rootScope.ContestGIUD;
            $data.MatchGUID        = $rootScope.MatchGUID;
            $data.UserTeamGUID     = $rootScope.UserTeamGUID;
            $data.SessionKey     = $sessionStorage.user_details.SessionKey;

            appDB
                .callPostForm('contest/join', $data)
                .then(
                    function successCallback(data) {
                        if (data.ResponseCode == 200) {
                            

                            $scope.closePopup('joinLeaguePopup');
                            var toast = toastr.success(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);

                            setTimeout(function(){
                                window.location.href = base_url+'lobby?MatchGUID='+getQueryStringValue('MatchGUID');
                            },5000);

                        }
                        if (data.ResponseCode == 500) {
                            var toast = toastr.warning(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                        }
                        if (data.ResponseCode == 501) {
                            var toast = toastr.warning(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                        }
                    },
                    function errorCallback(data) {

                        if (typeof data == 'object') {
                            var toast = toastr.error(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                        }
                    });


        }


        /*
            Description : To save user team 
        */      
        $rootScope.SaveTeam = function(){
            var $data = {};

            $data.MatchGUID             = getQueryStringValue('MatchGUID'); //   Match GUID
            $data.SessionKey            = $sessionStorage.user_details.SessionKey; //   User session key
            $data.UserTeamPlayers       = JSON.stringify($rootScope.selectedPlayers); //   User selected players
            $data.UserTeamName          = $scope.UserTeamName; //   User team name

            
            if(getQueryStringValue('Operation') && getQueryStringValue('Operation')=='edit'){
                var $url = 'contest/editUserTeam';
                $data.UserTeamGUID      = getQueryStringValue('UserTeamGUID');
            }else{
                var $url = 'contest/addUserTeam';
            }
            
            // var data = 'SessionKey='+$sessionStorage.user_details.SessionKey+'&MatchGUID='+getQueryStringValue('MatchGUID')+'&'+j$("form[name='SaveTeamForm']").serialize();
            // // console.log(data.selectedPlayers); return false;
            // console.log(typeof $("form[name='SaveTeamForm']").serialize());
            // $http.post($scope.env.api_url+$url, $.param(data), contentType).then(function(response) {
            //     var response = response.data;
            //     if(response.ResponseCode==200){ /* success case */               
                    
            //         var toast = toastr.success(response.Message, {
            //                         closeButton: true
            //                     });
            //                     toastr.refreshTimer(toast, 5000);
            //         $scope.data.dataList[$scope.data.Position] = response.Data;
            //         $('.modal-header .close').click();
            //     }else{
            //         var toast = toastr.warning(response.Message, {
            //                         closeButton: true
            //                     });
            //                     toastr.refreshTimer(toast, 5000);
            //     }
            // });


            appDB
                .callPostForm($url, $data)
                .then(
                    function successCallback(data) {
                        if (data.ResponseCode == 200) {
                            if(getQueryStringValue('League')){
                                $rootScope.ContestGIUD     = getQueryStringValue('League');
                                $rootScope.MatchGUID       = getQueryStringValue('MatchGUID');
                                $rootScope.UserTeamGUID    = data.Data.UserTeamGUID;

                                $scope.closePopup('selectCaptainViceCaptainModal');
                                $scope.UsersTeamList();

                                var toast = toastr.success(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                                setTimeout(function(){
                                    $scope.openPopup('joinLeaguePopup');
                                },3000);
                            }
                            else{
                                var toast = toastr.success(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                                setTimeout(function() {
                                    window.location.href = 'lobby?MatchGUID='+getQueryStringValue('MatchGUID');
                                }, 5000);
                            }
                        }
                        if (data.ResponseCode == 500) {
                            var toast = toastr.warning(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                        }
                        if (data.ResponseCode == 501) {
                            var toast = toastr.warning(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                        }
                    },
                    function errorCallback(data) {

                        if (typeof data == 'object') {
                            var toast = toastr.error(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                        }
                    });
        }

        /*Edit Team*/
        $scope.editTeam = function(){
            var $data = {};
            $data.MatchGUID    = getQueryStringValue('MatchGUID');
            $data.UserTeamGUID = getQueryStringValue('UserTeamGUID');
            $data.SessionKey   = $sessionStorage.user_details.SessionKey;
            $data.Params       = "PlayerGUID,PlayerName,PlayerCountry,PlayerPosition,PlayerRole,UserTeamPlayers,PlayerSalary";

            appDB
                .callPostForm('contest/getUserTeams', $data)
                .then(
                    function successCallback(data) {
                        if (data.ResponseCode == 200) {
                            $scope.resetTeamStructure();
                            $rootScope.selectedPlayers = [];
                            console.log(data.Data.UserTeamPlayers);
                            angular.forEach(data.Data.UserTeamPlayers,function(value,key){
                                $scope.addRemovePlayer(value.PlayerGUID,false,value);
                                if(value.PlayerPosition=='Captain'){
                                    $rootScope.Captain = value.PlayerGUID;
                                    $rootScope.selectCaptain(value.PlayerGUID);
                                }
                                if(value.PlayerPosition=='ViceCaptain'){
                                    $rootScope.ViceCaptain = value.PlayerGUID;
                                    $rootScope.selectViceCaptain(value.PlayerGUID);
                                }
                            });
                            $rootScope.UserTeamName = data.Data.UserTeamName;



                        }
                        if (data.ResponseCode == 500) {
                            var toast = toastr.warning(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                        }
                        if (data.ResponseCode == 501) {
                            var toast = toastr.warning(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                        }
                    },
                    function errorCallback(data) {

                        if (typeof data == 'object') {
                            var toast = toastr.error(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                        }
                    });

        }

        /*Copy Team Team*/
        $scope.copyTeam = function(){
            var $data = {};
            $data.MatchGUID    = getQueryStringValue('MatchGUID');
            $data.UserTeamGUID = getQueryStringValue('UserTeamGUID');
            $data.SessionKey   = $sessionStorage.user_details.SessionKey;
            $data.Params       = "PlayerGUID,PlayerName,PlayerCountry,PlayerPosition,PlayerRole,UserTeamPlayers,PlayerSalary";

            appDB
                .callPostForm('contest/getUserTeams', $data)
                .then(
                    function successCallback(data) {
                        if (data.ResponseCode == 200) {
                            $scope.resetTeamStructure();
                            $rootScope.selectedPlayers = [];
                            console.log(data.Data.UserTeamPlayers);
                            angular.forEach(data.Data.UserTeamPlayers,function(value,key){
                                // $scope.UserTeamPlayers[key].PlayerPosition = 'Player';
                                $scope.addRemovePlayer(value.PlayerGUID,false,value);
                            });

                            $scope.openPopup('selectCaptainViceCaptainModal');
                            var toast = toastr.success(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                        }
                        if (data.ResponseCode == 500) {
                            var toast = toastr.warning(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                        }
                        if (data.ResponseCode == 501) {
                            var toast = toastr.warning(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                        }
                    },
                    function errorCallback(data) {

                        if (typeof data == 'object') {
                            var toast = toastr.error(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                        }
                    });

        }
        if(getQueryStringValue('UserTeamGUID')){
            $scope.MatchPlayers();
            setTimeout(function(){
                $scope.copyTeam();
            },5000);
        }
        if(getQueryStringValue('Operation')=='edit'){
            $scope.MatchPlayers;
            setTimeout(function(){
                $scope.editTeam();
            },5000);
        }

        /*player info*/
        $scope.playersInfo = function(playerDetails){
            document.getElementById("playersInfoModal").style.width = "100%";
            $rootScope.playerDetails = {};
            $rootScope.playerDetails = playerDetails;
            $rootScope.PlayerBattingStats = playerDetails.PlayerBattingStats;
            $rootScope.PlayerBowlingStats = playerDetails.PlayerBowlingStats;
        }
        $rootScope.closeNav = function() {
            document.getElementById("playersInfoModal").style.width = "0";
        }

        $rootScope.activePlayerTab = 'play';
        $rootScope.playerDetailsTab = function(tab){
            $rootScope.activePlayerTab = tab;
        }

    } else {
        window.location.href = base_url;
    }
}]);