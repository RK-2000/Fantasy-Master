'use strict';
app.directive('addCash',['$localStorage','$sessionStorage','appDB','$location','toastr',function($localStorage,$sessionStorage,appDB,$location,toastr){
  return {
    restrict: 'E',
    controller:'headerController',
    templateUrl:'addCashPopup.php',
    link: function(scope, element, attributes){
      scope.openBolt = function(){
        bolt.launch({
          key: scope.payUData.MerchantKey,
          txnid: scope.payUData.TransactionID,
          hash: scope.payUData.Hash,
          amount: scope.payUData.Amount,
          firstname: scope.payUData.FirstName,
          email: scope.payUData.Email,
          phone: scope.payUData.PhoneNumber,
          productinfo: scope.payUData.ProductInfo.toString(),
          surl : scope.payUData.SuccessURL,
          furl : scope.payUData.FailedURL,
          lastname : '',
          curl : '',
          address1 : '',
          address2 : '',
          city : '',
          state : '',
          country : '',
          zipcode : '',
          udf1 : '',
          udf2 : '',
          udf3 : '',
          udf4 : '',
          udf5 : '',
          pg : '',
          enforce_paymethod : '',
          expirytime : ''
      },{
    responseHandler: function(get){
      
      console.log(JSON.stringify(get));

      if(get.response.txnStatus=='SUCCESS'){
        var status = 'Success';
      }else{
        var status = 'Failed';
      }

      var $data = {
                    "SessionKey": $sessionStorage.user_details.SessionKey,
                    "PaymentGateway":"PayUmoney",
                    "PaymentGatewayStatus":status,
                    "WalletID":get.response.productinfo,
                    "PaymentGatewayResponse":JSON.stringify(get.response)
                  };
      
      appDB
      .callPostForm('wallet/confirm',$data) 
      .then(
        function success(data){ 
          console.log(data);
          if(data.ResponseCode == 200){ 
            window.location.href = base_url+'myAccount?status=Success';
            $sessionStorage.user_details.WalletAmount = parseFloat(data.Data.WalletAmount).toFixed(2);
            var toast = toastr.success(data.Message, {
                closeButton: true
            });
            toastr.refreshTimer(toast, 5000);
          }
          else
          {
            window.location.href = base_url+'myAccount?status=Failed';
            var toast = toastr.error(data.Message, {
                closeButton: true
            });
            toastr.refreshTimer(toast, 5000);
          } 
        },
        function error(data){
          console.log('error',data);
        }
        );
      
    },
    catchException: function(get){
      alert(get.message);
    }
  });
      }
    }
  };
}]);
app.controller('headerController',['$scope','$rootScope','$location','environment','$localStorage','$sessionStorage','appDB','$sce',function($scope,$rootScope,$location,environment,$localStorage,$sessionStorage,appDB,$sce){
  $scope.env = environment;
  
  $scope.headerActiveMenu = 'matchCenter';
  var pathArray = window.location.pathname.split('/');
  var secondLevelLocation = pathArray[2];
  if(pathArray[2]=='lobby' || pathArray[2]=='league' || pathArray[2]=='createTeam' ){
    $scope.headerActiveMenu = 'matchCenter';  
  }else{
    $scope.headerActiveMenu = secondLevelLocation;
  }
  if($sessionStorage.hasOwnProperty('user_details') && $sessionStorage.isLoggedIn==true){
  	$scope.user_details = $sessionStorage.user_details;
  	$scope.isLoggedIn = $sessionStorage.isLoggedIn;
    $scope.base_url = base_url;
    $scope.referral_url = base_url+$sessionStorage.user_details.ReferralCode;
    

    /*function to show notifications*/
    $scope.notificationsArr = [];
    $scope.notifications = function(){
      var $data = {};
      $data.SessionKey = $sessionStorage.user_details.SessionKey;
        appDB
        .callPostForm('notifications',$data) 
        .then(
          function successCallback(data)
          { 
            if(data.ResponseCode == 200)
            { 
              $scope.notificationsArr = data.Data;  
            }
            if(data.ResponseCode == 500)
            { 
              window.location.href = base_url;
            }

          },
          function errorCallback(data)
          { 
            sessionStorage.clear();
          }
        );   
    }

    /*add cash popup*/
    $scope.addMoreCash=function(amnt){
      $scope.amount = (!$scope.amount) ? 0 : $scope.amount;
      $scope.amount=Number( $scope.amount)+amnt;
    }
    $scope.cashSubmitted = false;
    $scope.selectPaymentMode = function(amount,form){

      $scope.cashSubmitted = true;
        if(!form.$valid)
        {
          return false;
      }
      if(parseFloat(amount)<50)
      {
        $scope.errorAmount = true;
        $scope.errorAmountMsg = 'Min limit of adding balance is 50';
        return false;
      }

      $scope.isWalletSubmitted = false;
      if(!form.$valid)
      {
        $scope.isWalletSubmitted = true;
        return false;
      }
      if(parseFloat($scope.amount)>10000)
      {
        $scope.errorAmount = true;
        $scope.errorAmountMsg = 'Daily add cash limit is Rs 10000, Pls do varification of your KYC to increase limit.';
        return false;
      }
      if($scope.amount<50)
      {
        $scope.errorAmount = true;
        $scope.errorAmountMsg = 'Min limit of adding balance is 50';
        return false;
      }
      $rootScope.addBalance = {'amount':amount}; 
      $scope.closePopup('add_money');
      window.location.href = 'paymentMethod?amount='+amount;
    }
    /*validate amount*/
    $scope.validateAmount = function(){
      $scope.isWalletSubmitted = false;
      $scope.errorAmount = false;
      $scope.errorAmount = '';
      if($scope.amount.match(/^0[0-9].*$/))
      {
          $scope.amount = $scope.amount.replace(/^0+/, '');
      }
      if($scope.amount<50)
      {
          $scope.errorAmount = true;
          $scope.errorAmountMsg = 'Min limit of adding balance is 50';
          return false;
      }
      if($scope.amount>10000)
      {
        $scope.amount = 10000;
        $scope.errorAmount = true;
        $scope.errorAmountMsg = 'Daily add cash limit is Rs 10000, Pls do varification of your KYC to increase limit.';
        return false;
      }
    }
     /*PayU Money Request*/
    if(getQueryStringValue('amount')){
      $scope.amount = getQueryStringValue('amount');
    }
    $scope.payUReq=function(amount){
      var $data={};
      $data.SessionKey          =   $sessionStorage.user_details.SessionKey; 
      $data.PaymentGateway      =   'PayUmoney';
      $data.Amount              =   Number($scope.amount);
      $data.FirstName           =   $sessionStorage.user_details.FirstName;
      $data.Email               =   $sessionStorage.user_details.Email;
      $data.PhoneNumber         =   $sessionStorage.user_details.PhoneNumber;
      $scope.isWalletSubmitted  =   true;
      
      $rootScope.payUData = {};
     
      appDB
      .callPostForm('wallet/add',$data) 
      .then(
        function success(data){ 
          if(data.ResponseCode){ 
            $rootScope.payUData=data.Data;
            console.log($rootScope.payUData);
            setTimeout(function(){
              $scope.openBolt();
            },100);
          } 

          if(data.code == 200 && data.status == 2){ 
            $scope.logout();
          } 
        },
        function error(data){
          if (data!=null) {         
            $scope.paymentErr=data.message;
            $scope.openPopup('payment_failure');
          }
        }
        );
    }
    
    $scope.submitPayTmData=function(payTmData){
      angular.element('#submitPayTm').trigger('submit')
    }

    $scope.addExtraCash = function(amount){
      $scope.amount = parseFloat($scope.amount)+parseFloat(amount);
    }

  }

  /*Logout*/
  $scope.logout = function(){
  	
  	var $data = {};
  	$data.SessionKey = $sessionStorage.user_details.SessionKey;
  	appDB
    .callPostForm('signin/signout/',$data) 
    .then(
        function successCallback(data)
        { 
          if(data.ResponseCode == 200)
	        { 
	        	sessionStorage.clear();
            
            window.location.href= base_url;
          }

        },
        function errorCallback(data)
        { 
          sessionStorage.clear();
    	}
	);    
  }

}]);
