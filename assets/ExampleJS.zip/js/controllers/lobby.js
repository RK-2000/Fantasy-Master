'use strict';
app.directive('createContest',function(){
 return {
  restrict: 'E',
  controller:'createContestController',
  templateUrl:'createContest.php',
  link: function(scope, element, attributes){
    scope.contest_size = 2;
    scope.closeContestPopup = function(){
      scope.closePopup('creat_contest');
        scope.contestError = false;
        scope.calculation_error = false;
        scope.calculation_error_msg = false;
        delete scope.winnings;
        scope.number_of_winners = '';
        scope.total_winning_amount = 0;
        scope.contest_sizes = 2;
        scope.submitted = false;
      scope.clearPopup();
    }
    scope.isSetUp = false;
    scope.clearContent = function(){

    }
    scope.clearPopup = function(){
      scope.contest_name = '';
      scope.number_of_winners = '';
      scope.is_multientry = false;
      scope.winnings = false;
      //scope.contest_sizes = 0;
      scope.contest_sizes = 2;
      scope.total_winning_amount = 0;
      scope.clearForm();
      scope.submitted = false;
    }
  }
};
});
app.controller('lobbyController', ['$scope', '$rootScope', '$location', 'environment', '$localStorage', '$sessionStorage', 'appDB', 'toastr', function($scope, $rootScope, $location, environment, $localStorage, $sessionStorage, appDB, toastr) {
    $scope.env = environment;
    $scope.data.pageSize = 15;
    $scope.data.pageNo = 1;
    $scope.coreLogic = Mobiweb.helpers;
    $scope.ContestsTotalCount = 0;
    $scope.UserTeamsTotalCount = 0;
    $scope.UserJoinedContestTotalCount = 0;

    if ($sessionStorage.hasOwnProperty('user_details') && $sessionStorage.isLoggedIn == true) {
        $scope.user_details = $sessionStorage.user_details;
        $scope.MatchGUID    = getQueryStringValue('MatchGUID');
        /*get url params*/
        if (!getQueryStringValue('MatchGUID')) {
            window.location.href = 'matchCenter';
        } else {
            /*To manage Tabs*/
            $scope.activeTab = 'normal';
            $scope.gotoTab = function(tab) {
                $scope.activeTab = tab;
            }

            $rootScope.MatchGUID = getQueryStringValue('MatchGUID'); //Match GUID

            /*Function to get mactch center details*/
            $scope.MatchesDetail = {};
            $scope.matchCenterDetails = function() {

                var $data = {};
                $data.MatchGUID = getQueryStringValue('MatchGUID'); //   Match GUID
                $rootScope.MatchGUID = getQueryStringValue('MatchGUID'); //   Match GUID
                $data.Params = 'SeriesName,MatchType,MatchNo,MatchStartDateTime,TeamNameLocal,TeamNameVisitor,TeamNameShortLocal,TeamNameShortVisitor,TeamFlagLocal,TeamFlagVisitor,MatchLocation,SeriesGUID,Status';
                appDB
                    .callPostForm('sports/getMatch', $data)
                    .then(
                        function successCallback(data) {
                            if (data.ResponseCode == 200) {
                                $scope.MatchesDetail = data.Data;
                                $rootScope.CurrentSelectedMatchDetail = data.Data;
                                if($scope.MatchesDetail.Status!='Pending'){
                                    $scope.gotoTab('joined');
                                    $scope.JoinedContest();
                                }else if($scope.MatchesDetail.Status=='Pending'){
                                    $scope.getContests();
                                }
                                $scope.LobbyCounters();
                            }
                            if (data.ResponseCode == 500) {
                                var toast = toastr.warning(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                            }
                            if (data.ResponseCode == 501) {
                                var toast = toastr.warning(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                            }
                        },
                        function errorCallback(data) {

                            if (typeof data == 'object') {
                                var toast = toastr.error(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                            }
                        });
            }
            /*
            Description : To get user created team list
            */
            $scope.userTeamList = [];
            $scope.UsersTeamList = function() {
                var $data = {};
                if ($scope.data.listLoading || $scope.data.noRecords) return;
                $scope.data.listLoading = true;
                $scope.userTeamList = []; //user team list array
                $data.SessionKey    = $sessionStorage.user_details.SessionKey; //user session key
                $data.MatchGUID     = getQueryStringValue('MatchGUID'); //Match GUID
                $data.Params        = 'UserTeamName';
                $data.PageNo        = 0;
                $data.PageSize      = $scope.data.pageSize;
                $data.Keyword       = $scope.Keyword;
                appDB
                    .callPostForm('contest/getUserTeams', $data)
                    .then(
                        function successCallback(data) {
                            if (data.ResponseCode == 200) {
                                console.log(data);
                                if(data.Data.hasOwnProperty('Records')){
                                    $scope.userTeamList = data.Data;
                                    for (var i in data.Data.Records) {
                                        $scope.data.dataList.push(data.Data.Records[i]);
                                    }
                                    $scope.data.pageNo++;
                                    $scope.data.listLoading = false;
                                }
                                else{
                                    $scope.userTeamList = [];
                                    $scope.data.noRecords = true;
                                   
                                }
                                $scope.UserTeamsTotalCount = data.Data.TotalRecords;
                            } else {
                                $scope.data.noRecords = true;
                            }
                            if (data.ResponseCode == 500) {
                                var toast = toastr.warning(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                                $scope.data.noRecords = true;
                            }
                            if (data.ResponseCode == 501) {
                                var toast = toastr.warning(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                                $scope.data.noRecords = true;
                            }
                        },
                        function errorCallback(data) {

                            if (typeof data == 'object') {
                                var toast = toastr.error(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                                $scope.data.noRecords = true;
                            }
                        });

            }

            /*Change filter*/
            var $data = {};
            $scope.changeFilter = function(filter){
                $data.OrderBy = filter;
                if($scope.filter){
                    $data.Sequence = 'ASC';
                }else{
                    $data.Sequence = 'DESC';
                }
                if(filter=='IsPaid'){
                    $data.IsPaid = 'No'; 
                }
                $scope.getContests();
                
            }

            $scope.changeJoinedFilter = function(filter){
                $data.OrderBy = filter;
                if($scope.filter){
                    $data.Sequence = 'ASC';
                }else{
                    $data.Sequence = 'DESC';
                }
                if(filter=='IsPaid'){
                    $data.IsPaid = 'No'; 
                }
                $scope.JoinedContest();
                
            }
            /*function to get contests according to matches*/
            $scope.Contests = [];
            $scope.getContests = function() {
                
                if ($scope.data.listLoading || $scope.data.noRecords) return;
                $scope.data.listLoading = true;
                
                $data.MatchGUID = getQueryStringValue('MatchGUID'); // Selected MatchGUID
                $data.SessionKey = $sessionStorage.user_details.SessionKey; // User SessionKey
                $data.PageNo = $scope.data.pageNo; // Page Number
                $data.PageSize    = $scope.data.pageSize; // Page Size
                $data.SessionKey = $sessionStorage.user_details.SessionKey; // User SessionKey
                $data.Params = 'Privacy,IsPaid,WinningAmount,ContestSize,EntryFee,NoOfWinners,EntryType,IsJoined,Status,ContestFormat,ContestType,CustomizeWinning,TotalJoined,UserInvitationCode,TeamNameLocal,TeamNameVisitor';
                $data.Keyword = $scope.Keyword;
                $data.Status = ['1','2','5'];

                if($scope.activeTab=='pvt'){
                    $data.UserGUID = $sessionStorage.user_details.UserGUID;
                    $data.Privacy = 'Yes';
                }
                else{
                    $data.Privacy = 'No';
                }

                // $data.Status = '1,2,5';

                appDB
                    .callPostForm('contest/getContests', $data)
                    .then(
                        function successCallback(data) {
                            if (data.ResponseCode == 200) {

                                $scope.Contests = data.Data;
                                $scope.ContestsTotalCount = data.Data.TotalRecords;
                                for (var i in data.Data.Records) {
                                    $scope.data.dataList.push(data.Data.Records[i]);
                                }
                                $scope.data.pageNo++;               
                                angular.forEach($scope.Contests.Records,function(value,key){
                                    $scope.data.dataList[key].joinedpercent = parseInt(value.TotalJoined) * 100 / parseInt(value.ContestSize);
                                });
                                $scope.data.listLoading = false;
                                $scope.UsersTeamList();
                            } else {
                                $scope.data.noRecords = true;
                            }
                            if (data.ResponseCode == 500) {
                                var toast = toastr.warning(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                                $scope.data.noRecords = true;
                            }
                            if (data.ResponseCode == 501) {
                                var toast = toastr.warning(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                                $scope.data.noRecords = true;
                            }
                        },
                        function errorCallback(data) {

                            if (typeof data == 'object') {
                                var toast = toastr.error(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                                $scope.data.noRecords = true;
                            }
                        });
                $scope.data.listLoading = false;
            }
     

            

            /*To Check Team to Join Contest*/
            $scope.SelectTeamToJoinContest = function(ContestGUID){
                if($scope.userTeamList.length <= 0){
                    /*Redirect to create team*/
                    window.location.href = base_url+'createTeam?MatchGUID='+getQueryStringValue('MatchGUID')+'&League='+ContestGUID; 
                }else{
                    $scope.ContestGUID = ContestGUID;
                    $scope.openPopup('joinLeaguePopup');
                }

            }
            /*end of else*/
        }

        /*
          Description : To get user team details on ground
        */



        $scope.ViewTeamOnGround = function(UserTeamGUID) {
            var $data = {};



            $scope.TeamPlayers = []; //user team list array
            $data.SessionKey = $sessionStorage.user_details.SessionKey; //user session key
            $data.UserTeamGUID = UserTeamGUID; //User Team GUID
            $data.MatchGUID = getQueryStringValue('MatchGUID'); //Match GUID
            $data.Params = "PlayerGUID,PlayerName,PlayerPic,PlayerCountry,PlayerPosition,PlayerRole,UserTeamPlayers";

            appDB
                .callPostForm('contest/getUserTeams', $data)
                .then(
                    function successCallback(data) {
                        if (data.ResponseCode == 200) {
                            document.getElementById("mySidenav").style.width = "75%";
                            $scope.TeamPlayers = data.Data;
                            $scope.teamStructure = {
                                "WicketKeeper": {
                                    "min": 1,
                                    "max": 1,
                                    "occupied": 0,
                                    player: [],
                                    "icon": "flaticon1-pair-of-gloves"
                                },
                                "Batsman": {
                                    "min": 3,
                                    "max": 5,
                                    "occupied": 0,
                                    player: [],
                                    "icon": "flaticon1-ball"
                                },
                                "Bowler": {
                                    "min": 3,
                                    "max": 5,
                                    "occupied": 0,
                                    player: [],
                                    "icon": "flaticon1-tennis-ball"
                                },
                                "AllRounder": {
                                    "min": 1,
                                    "max": 3,
                                    "occupied": 0,
                                    player: [],
                                    "icon": "flaticon1-ball"
                                },
                                "Extra": {
                                    "min": 3,
                                    "max": 3,
                                    occupied: 0,
                                    player: []
                                },
                                "ready": false
                            };
                            angular.forEach($scope.TeamPlayers.UserTeamPlayers, function(value, key) {
                                if (value.PlayerRole == 'WicketKeeper') {

                                    $scope.teamStructure['WicketKeeper'].player.push({
                                        'PlayerGUID': value.PlayerGUID,
                                        'PlayerPosition': value.PlayerPosition,
                                        'PlayerName': value.PlayerName,
                                        'PlayerPic' : value.PlayerPic
                                    });
                                    $scope.teamStructure['WicketKeeper'].occupied++;
                                }
                                if (value.PlayerRole == 'Batsman') {
                                    $scope.teamStructure['Batsman'].player.push({
                                        'PlayerGUID': value.PlayerGUID,
                                        'PlayerPosition': value.PlayerPosition,
                                        'PlayerName': value.PlayerName,
                                        'PlayerPic' : value.PlayerPic
                                    });
                                    $scope.teamStructure['Batsman'].occupied++;
                                }
                                if (value.PlayerRole == 'AllRounder') {
                                    $scope.teamStructure['AllRounder'].player.push({
                                        'PlayerGUID': value.PlayerGUID,
                                        'PlayerPosition': value.PlayerPosition,
                                        'PlayerName': value.PlayerName,
                                        'PlayerPic' : value.PlayerPic
                                    });
                                    $scope.teamStructure['AllRounder'].occupied++;
                                }
                                if (value.PlayerRole == 'Bowler') {
                                    $scope.teamStructure['Bowler'].player.push({
                                        'PlayerGUID': value.PlayerGUID,
                                        'PlayerPosition': value.PlayerPosition,
                                        'PlayerName': value.PlayerName,
                                        'PlayerPic' : value.PlayerPic
                                    });
                                    $scope.teamStructure['Bowler'].occupied++;
                                }
                            });
                            
                        } else {
                            $scope.data.noRecords = true;
                        }
                        if (data.ResponseCode == 500) {
                            var toast = toastr.warning(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                            $scope.data.noRecords = true;
                        }
                        if (data.ResponseCode == 501) {
                            var toast = toastr.warning(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                            $scope.data.noRecords = true;
                        }
                    },
                    function errorCallback(data) {

                        if (typeof data == 'object') {
                            var toast = toastr.error(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                            $scope.data.noRecords = true;
                        }
                    });
        }
        $scope.closeNav = function() {
            document.getElementById("mySidenav").style.width = "0";
        }

        


        /*To get User joined contest */

        var $data = {};
        $scope.JoinedContest = function(){
            $scope.Contests = []; //user team list array
            $scope.data.dataList = [];
            // if ($scope.data.listLoading || $scope.data.noRecords) return;
            // console.log('jhvjkhvkjvh'); return false;
            $scope.data.listLoading = true;
            $data.SessionKey = $sessionStorage.user_details.SessionKey; //user session key
            $data.MatchGUID = getQueryStringValue('MatchGUID'); //Match GUID
            $data.Params = 'Privacy,IsPaid,WinningAmount,ContestSize,EntryFee,NoOfWinners,EntryType,Status,TotalJoined,CustomizeWinning';
            $data.PageNo = $scope.data.pageNo;
            $data.PageSize = $scope.data.pageSize;
            appDB
                .callPostForm('contest/getJoinedContests', $data)
                .then(
                    function successCallback(data) {
                        if (data.ResponseCode == 200 && data.Data.Records) {
                            $scope.Contests = data.Data;
                            $scope.UserJoinedContestTotalCount = data.Data.TotalRecords;
                            for (var i in data.Data.Records) {
                                $scope.data.dataList.push(data.Data.Records[i]);
                            }
                            $scope.data.pageNo++;
                            angular.forEach($scope.Contests.Records,function(value,key){
                                $scope.data.dataList[key].joinedpercent = parseInt(value.TotalJoined) * 100 / parseInt(value.ContestSize);
                            });
                            $scope.data.listLoading = false;

                        } else {
                            $scope.data.noRecords = true;
                        }
                        if (data.ResponseCode == 500) {
                            var toast = toastr.warning(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                            $scope.data.noRecords = true;
                        }
                        if (data.ResponseCode == 501) {
                            var toast = toastr.warning(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                            $scope.data.noRecords = true;
                        }
                    },
                    function errorCallback(data) {

                        if (typeof data == 'object') {
                            var toast = toastr.error(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                            $scope.data.noRecords = true;
                        }
                    });

        }

        /*To join Contest*/
        $scope.join = {};
        $scope.joinSubmitted = false;
        $rootScope.JoinContest = function(form){
            $scope.joinSubmitted = true;
            if(!form.$valid)
            {
              return false;
            }
            var $data = {};
            $data = $scope.join;
            $data.ContestGUID = $scope.ContestGUID;
            $data.SessionKey = $sessionStorage.user_details.SessionKey;
            
            appDB
                .callPostForm('contest/join', $data)
                .then(
                    function successCallback(data) {
                        if (data.ResponseCode == 200) {
                            $scope.closePopup('joinLeaguePopup');
                            
                            var toast = toastr.success(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                            setTimeout(function() {
                                $scope.data.pageNo = 1;
                                $scope.getContests();
                            }, 3000);
                        } else {
                            $scope.data.noRecords = true;
                        }
                        if (data.ResponseCode == 500) {
                            var toast = toastr.warning(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                            $scope.data.noRecords = true;
                        }
                        if (data.ResponseCode == 501) {
                            var toast = toastr.warning(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                            $scope.data.noRecords = true;
                        }
                    },
                    function errorCallback(data) {

                        if (typeof data == 'object') {
                            var toast = toastr.error(data.Message, {
                                closeButton: true
                            });
                            toastr.refreshTimer(toast, 5000);
                            $scope.data.noRecords = true;
                        }
                    });
        }

        /*
            Description:To show counters
        */
        $scope.LobbyCounters = function(){
            // statics
            $scope.counters = [];
            var $data = {};
            $data.MatchGUID     = getQueryStringValue('MatchGUID'); //   Match GUID
            $data.SessionKey    = $sessionStorage.user_details.SessionKey; //   Match GUID
            
            // appDB
            //     .callPostForm('contest/statics', $data)
            //     .then(
            //         function successCallback(data) {
            //             if (data.ResponseCode == 200) {
            //                 $scope.counters = data.Data;
            //                 console.log($scope.counters);
            //             }
            //             if (data.ResponseCode == 500) {
            //                 var toast = toastr.warning(data.Message, {
            //                     closeButton: true
            //                 });
            //                 toastr.refreshTimer(toast, 5000);
            //             }
            //             if (data.ResponseCode == 501) {
            //                 var toast = toastr.warning(data.Message, {
            //                     closeButton: true
            //                 });
            //                 toastr.refreshTimer(toast, 5000);
            //             }
            //         },
            //         function errorCallback(data) {

            //             if (typeof data == 'object') {
            //                 var toast = toastr.error(data.Message, {
            //                     closeButton: true
            //                 });
            //                 toastr.refreshTimer(toast, 5000);
            //             }
            //         });
        }

        /*
            Description : To check private contest and join
        */
        $scope.codeSubmitted = false;
        $scope.checkContestCode = function(form,UserInvitationCode){
            $scope.codeSubmitted = true;
            if(!form.$valid)
            {
              return false;
            }
            $scope.UsersTeamList();
                if ($scope.data.listLoading || $scope.data.noRecords) return;
                $scope.data.listLoading = true;
                var $data = {};
                $data.SessionKey = $sessionStorage.user_details.SessionKey; // User SessionKey
                $data.Params = 'IsPaid,WinningAmount,ContestSize,EntryFee,NoOfWinners,EntryType,TotalJoined,CustomizeWinning';
                $data.UserInvitationCode = UserInvitationCode;

                appDB
                    .callPostForm('contest/getPrivateContest', $data)
                    .then(
                        function successCallback(data) {
                            if (data.ResponseCode == 200) {

                                $scope.Contests = data.Data;
                                $scope.ContestsTotalCount = data.Data.TotalRecords;
                                if(($scope.Contests.length==0)){
                                    var toast = toastr.warning('Invalid Contest Code', {
                                        closeButton: true
                                    });
                                    toastr.refreshTimer(toast, 5000);
                                }else{
                                    $scope.SelectTeamToJoinContest($scope.Contests.ContestGUID);
                                }
                                $scope.data.listLoading = false;
                            } else {
                                $scope.data.noRecords = true;
                            }
                            if (data.ResponseCode == 500) {
                                var toast = toastr.warning(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                                $scope.data.noRecords = true;
                            }
                            if (data.ResponseCode == 501) {
                                var toast = toastr.warning(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                                $scope.data.noRecords = true;
                            }
                        },
                        function errorCallback(data) {

                            if (typeof data == 'object') {
                                var toast = toastr.error(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                                $scope.data.noRecords = true;
                            }
                        });
                $scope.data.listLoading = false;
        }
    } else {

        window.location.href = base_url;
    }

}]);


app.controller('createContestController', ['$scope', '$rootScope', '$location', 'environment', '$localStorage', '$sessionStorage', 'appDB', 'toastr', function($scope, $rootScope, $location, environment, $localStorage, $sessionStorage, appDB, toastr) {
    $scope.env = environment;

    $scope.coreLogic = Mobiweb.helpers;
    if ($sessionStorage.hasOwnProperty('user_details') && $sessionStorage.isLoggedIn == true) {
        $scope.user_details = $sessionStorage.user_details;
        $scope.ContestFormat = 'Head to Head';
        /*get url params*/
        if (!getQueryStringValue('MatchGUID')) {
            window.location.href = 'matchCenter';
        } else {
            $rootScope.MatchGUID = getQueryStringValue('MatchGUID'); //Match GUID

            /*create contest calculations starts*/
            $scope.clearForm = function() {
                $scope.showField = false;
                $scope.choices = [];
                $scope.choices.push({
                    row: 0,
                    select_1: 1,
                    select_2: 1,
                    amount: 0.00,
                    percent: 0
                });

                if ($scope.NoOfWinners && $scope.contest_sizes) {
                    if ($scope.numbers == '') {
                        for (var i = 1; i <= parseInt($scope.NoOfWinners); i++) {
                            $scope.numbers.push(i);
                        }
                    } else {
                        for (var i = 1; i <= parseInt($scope.NoOfWinners); i++) {
                            $scope.numbers.push(i)
                            $scope.numbers.splice(i);
                        }
                    }
                }
            }
            $scope.totalPercentage = 0; // For Contest Creation Belives total Percentage is 0
            $scope.totalPersonCount = 0; // For Contest Creation Belives total Person count is 0
            $scope.currentSelectedMatch = 0; //To maintain current Selected Match Id
            /*------------calculate entryFee-------------------*/
            $scope.adminPercent = 10;
            $scope.ContestSize = 2;
            $scope.showSeries = true;
            $scope.contestError = false;
            $scope.contestErrorMsg = '';

            /*Function to Fetch Matches*/
            $scope.$watch('ContestSize', function(newValue, oldValue) {
                $scope.NoOfWinners = '';
                
                if (newValue != oldValue) {
                    if (typeof newValue == 'undefined') {
                        $scope.EntryFee = 0.00;
                        return false;
                    }
                    if (newValue > 100) {
                        $scope.ContestSize = 100;
                    } else if ($scope.ContestSize.match(/^0[0-9].*$/)) {
                        $scope.ContestSize = $scope.ContestSize.replace(/^0+/, '');
                    }


                    if (parseInt($scope.ContestSize) > 0) {
                        $scope.totalEntry = $scope.WinningAmount / $scope.ContestSize;
                        $scope.EntryFee = ($scope.totalEntry * $scope.adminPercent / 100 + $scope.totalEntry).toFixed(2);
                    } else {
                        $scope.EntryFee = 0;
                    }

                }
            });

            $scope.$watch('WinningAmount', function(newValue, oldValue) {
                if (newValue != oldValue) {
                    if (typeof newValue == 'undefined') {
                        $scope.EntryFee = 0.00;
                        return false;
                    }
                    if (newValue > 10000) {
                        $scope.WinningAmount = 10000;
                    }
                    if ($scope.WinningAmount.match(/^0[0-9].*$/)) {
                        $scope.WinningAmount = $scope.WinningAmount.replace(/^0+/, '');
                    }
                    if (parseInt($scope.ContestSize) > 0) {
                        $scope.totalEntry = $scope.WinningAmount / $scope.ContestSize;
                        $scope.EntryFee = ($scope.totalEntry * $scope.adminPercent / 100 + $scope.totalEntry).toFixed(2);
                    } else {
                        $scope.EntryFee = 0;
                    }
                    $scope.clearForm();
                }
            });

            /*------------calculate Percent and Amount-------------------*/
            $scope.choices = [];
            $scope.amount = 0.00;

            $scope.changePercent = function(x) {
                /*Remove Error First*/
                $scope.calculation_error = false;
                $scope.calculation_error_msg = '';
                /*Remove Error First*/
                if (x != 0 && x > 0) {
                    let tempPersnCount1 = ($scope.choices[x].select_2 - $scope.choices[x].select_1) + 1;
                    let tempPersnCount0 = ($scope.choices[x - 1].select_2 - $scope.choices[x - 1].select_1) + 1;
                    if ((parseFloat(($scope.WinningAmount * $scope.choices[x].percent) / 100) / tempPersnCount1) > (parseFloat($scope.WinningAmount * $scope.choices[x - 1].percent / 100) / tempPersnCount0)) {
                        $scope.choices[x].percent = '';
                        $scope.choices[x].amount = parseFloat(0);
                        return false;
                    }
                }
                let total = 0;
                for (var i = 0; i < $scope.choices.length; i++) {
                    total = total + parseFloat($scope.choices[i].percent);
                }
                if (total > 100) {
                    $scope.choices[x].percent = '';
                    $scope.calculation_error = true;
                    $scope.calculation_error_msg = 'Sum of percentage can not be more then 100%';
                    $scope.choices[x].amount = parseFloat(0);
                    return false;
                }

                for (var i = 0; i < $scope.choices.length; i++) {
                    if (i === x) {
                        let persenCount = 0;
                        if (parseInt($scope.choices[i].select_2) == parseInt($scope.choices[i].select_1)) {
                            persenCount = 1;
                        } else {
                            persenCount = ($scope.choices[i].select_2 - $scope.choices[i].select_1) + 1;
                        }
                        $scope.winnersAmount = $scope.WinningAmount * $scope.choices[i].percent / 100;
                        let amount = ($scope.winnersAmount / persenCount).toFixed(2);
                        let fractionNumber = amount.split('.');
                        amount = fractionNumber[0] + '.' + fractionNumber[1].slice(0, 1);
                        $scope.choices[i].amount = amount;
                        $scope.choices[i].percent = $scope.choices[i].percent.toString();
                        if ($scope.choices[i].percent.match(/^0[0-9].*$/)) {
                            $scope.WinningAmount = $scope.WinningAmount.replace(/^0+/, '');
                        }
                        $scope.choices[i].percent = $scope.choices[i].percent.replace(/^0+/, '');
                    }
                }
            }
            $scope.customizeMultieams = function() {
                $scope.calculation_error = false;
                $scope.calculation_error_msg = '';
                if ($scope.ContestSize == null || $scope.ContestSize < 3) {
                    $scope.calculation_error = true;
                    $scope.calculation_error_msg = "Contest size must be greater then 2!";
                    $scope.EntryType = 'Single';
                    return false;
                }
            }
            $scope.customizeWin = function() {
                $scope.calculation_error = false;
                $scope.calculation_error_msg = '';
                if ($scope.winnings == "") {
                    $scope.showField = false;
                    $scope.NoOfWinners = '';
                    return false;
                }
                if ($scope.WinningAmount == null || $scope.WinningAmount < 1) {
                    $scope.calculation_error = true;
                    $scope.calculation_error_msg = "Please enter total winning amount!";
                    $scope.winnings = false;
                    return false;
                }
                if ($scope.ContestSize == null || $scope.ContestSize < 2) {
                    $scope.calculation_error = true;
                    $scope.calculation_error_msg = "Contest size must be greater or equals to 2";
                    $scope.winnings = false;
                    return false;
                }
            }
            $scope.changeWinAmount = function() {
                $scope.calculation_error = false;
                $scope.calculation_error_msg = '';
                if ($scope.WinningAmount == null || $scope.WinningAmount < 1) {
                    $scope.winnings = false;
                }
            }
            $scope.changeWinners = function() {
                $scope.EntryType = 'Single';
                $scope.calculation_error = false;
                $scope.calculation_error_msg = '';
                if ($scope.ContestSize == null || $scope.ContestSize < 2) {
                    $scope.winnings = false;
                }
                $scope.showField = false;
                $scope.contestError = false;
                $scope.clearForm();
            }
            /*---------------add and remove Field-------------------*/
            $scope.select_1 = 1;
            var x = 0;
            $scope.choices.push({
                row: x,
                select_1: 1,
                select_2: 1,
                amount: 0.00,
                percent: 0
            });
            $scope.addField = function() {
                x = x + 1;
                $scope.numbers1 = [];

                var select2_value = "";
                $scope.percent_error = false;
                var lastIndex = $scope.choices.length - 1;
                if ($scope.choices[lastIndex].percent == 0) {
                    $scope.calculation_error = true;
                    $scope.calculation_error_msg = "Last percentage is blank!";
                    return false;
                }
                if ($scope.totalPercentage == 100) {
                    $scope.calculation_error = true;
                    $scope.calculation_error_msg = "Amount has been distributed already!";
                    return false;
                }
                for (var k = 0; $scope.choices.length > k; k++) {

                    if (k == $scope.choices.length - 1) {
                        if ($scope.choices[k].percent) {
                            select2_value = ($scope.choices[k].select_2 + 1);
                            for (var j = ($scope.choices[k].select_2 + 1); j <= parseInt($scope.NoOfWinners); j++) {
                                $scope.numbers1.push(j)
                            }
                        } else {
                            $scope.percent_error = true;
                            return false;
                        }
                    }
                }
                if (select2_value <= parseInt($scope.NoOfWinners)) {
                    $scope.choices.push({
                        row: x,
                        select_1: select2_value,
                        select_2: select2_value,
                        numbers: $scope.numbers1,
                        percent: 0,
                        amount: 0.00
                    });
                } else {
                    $scope.calculation_error = true;
                    $scope.calculation_error_msg = "All Winners has been selected already!";
                }

            }
            $scope.$watch('choices', function(n, o, scope) {
                var totalPercentagetemp = 0;
                var isRemoval = false;
                var removalIndex = 0;
                /*Code to track Changes in top rows and if any remove below rows*/
                if ($scope.choices.length > 1) {
                    for (var counter = 0; counter < $scope.choices.length; counter++) {
                        if (counter < o.length - 1 && (o[counter].amount != n[counter].amount || o[counter].select_2 != o[counter].select_2)) {
                            isRemoval = true;
                            removalIndex = counter + 1;
                        }
                    }
                }
                if (isRemoval == true) {
                    var numberOfRows = $scope.choices.length;
                    if (removalIndex <= numberOfRows - 1) {
                        var removeElementCount = numberOfRows - removalIndex;
                        $scope.choices.splice(removalIndex, removeElementCount);
                    }

                }
                /*Code to track Changes in top rows and if any remove below rows*/

                /*Total Percentage Count and Handler*/
                for (var counter = 0; counter < $scope.choices.length; counter++) {
                    totalPercentagetemp += parseFloat($scope.choices[counter].percent);
                }
                if (totalPercentagetemp > 100) {
                    $scope.choices = 0;
                    return false;
                }
                $scope.totalPercentage = totalPercentagetemp;
                /*Total Percentage count and handler*/

                /*Total Person count and Handler*/
                let personCount = 0;
                for (var i = 0; i < $scope.choices.length; i++) {
                    if ($scope.choices[i].select_1 == $scope.choices[i].select_2) {
                        personCount++;
                    } else {
                        personCount += parseInt(($scope.choices[i].select_2 - $scope.choices[i].select_1) + 1);
                    }
                }
                $scope.totalPersonCount = personCount;
                /*Total Person Count and Handler*/
            }, true);

            /*Handle Contest Size*/
            $scope.$watch('NoOfWinners', function(newValue, oldValue) {
                if (parseInt(newValue) > parseInt($scope.ContestSize)) {
                    $scope.NoOfWinners = oldValue;
                }
            });

            /*Handle Contest Size*/
            $scope.$watch('ContestFormat', function(newValue, oldValue) {
                if(newValue == 'Head to Head' || oldValue=='Head to Head'){
                    $scope.ContestSize = '2';
                }
            });



            $rootScope.removeField = function(index) {
                if (index == 0) {
                    $scope.calculation_error = true;
                    $scope.calculation_error_msg = "You can not remove first row.";
                    return false;
                }
                if (index < $scope.choices.length - 1) {
                    $scope.calculation_error = true;
                    $scope.calculation_error_msg = "While having row beneath you can not delete current row.";
                    return false;
                }
                if (index >= 0) {
                    $scope.choices.splice(index, 1);
                    $scope.calculation_error = false;
                    $scope.calculation_error_msg = '';
                }
            }



            /*------------ show  and hide form-------------------*/
            $scope.showField = false;
            $scope.numbers = [];
            $rootScope.Showform = function() {
           
                if ($scope.NoOfWinners == '' || $scope.NoOfWinners == '0') {
                    $scope.calculation_error = true;
                    $scope.calculation_error_msg = "Please enter proper winner count!";
                    return false;
                }

                if ($scope.NoOfWinners && $scope.ContestSize) {
                    if ($scope.numbers == '') {
                        for (var i = 1; i <= parseInt($scope.NoOfWinners); i++) {
                            $scope.numbers.push(i);
                        }
                    } else {
                        for (var i = 1; i <= parseInt($scope.NoOfWinners); i++) {
                            $scope.numbers.push(i)
                            $scope.numbers.splice(i);
                        }
                    }
                    $scope.choices[0].numbers = $scope.numbers;
                    if (parseInt($scope.ContestSize) >= parseInt($scope.NoOfWinners)) {
                        $scope.error = false;
                        $scope.showField = true;
                    } else {
                        $scope.error = true;
                        $scope.showField = false;
                        return false;
                    }
                } else {
                    $scope.error = true;
                    $scope.showField = false;
                    $scope.calculation_error = true;
                    $scope.calculation_error_msg = "Please enter proper winner count!";
                    return false;
                }
            }
            /*create contest calculations ends*/
            
            $scope.contestPrizeParser = function($choices)
            { 
                let response = [];
                let valueArray = [];
                for(var $i=0;$i<$scope.choices.length;$i++)
                {
                    valueArray.push({'From' : $scope.choices[$i].select_1,'To' : $scope.choices[$i].select_2,'Percent' : $scope.choices[$i].percent,'WinningAmount':$scope.choices[$i].amount});
                }
                response = valueArray;
                return response;
            }
            /*
              Description : To create private Contest
            */
            $scope.createContestField = {};
            $scope.submitted = false;
            $scope.CreateContest = function(form) {
                
                $scope.helpers = Mobiweb.helpers;
                $scope.submitted = true;
                if (!form.$valid) {
                    return false;
                }

                var $data = {};

                $scope.createContestField.SessionKey    = $sessionStorage.user_details.SessionKey;
                $scope.createContestField.SeriesGUID    = $scope.MatchesDetail.SeriesGUID;
                $scope.createContestField.MatchGUID     = getQueryStringValue('MatchGUID');
                $scope.createContestField.Privacy       = 'Yes';
                $scope.createContestField.IsPaid        = 'Yes';
                $scope.createContestField.ContestFormat = $scope.ContestFormat;
                $scope.createContestField.ContestName   = $scope.ContestName;
                $scope.createContestField.ContestType   = $scope.ContestType;
                $scope.createContestField.WinningAmount = $scope.WinningAmount;
                $scope.createContestField.EntryFee      = $scope.EntryFee;
                $scope.createContestField.NoOfWinners   = $scope.NoOfWinners;
                $scope.createContestField.EntryType     = $scope.EntryType;
                if($scope.ContestFormat=='Head to Head'){
                    $scope.createContestField.ContestSize = 2;    
                }else{
                    $scope.createContestField.ContestSize   = $scope.ContestSize;
                }
                if($scope.winnings){
                    $scope.createContestField.customWinings   = JSON.stringify($scope.contestPrizeParser($scope.choices));
                }
                $data = $scope.createContestField;
                appDB
                    .callPostForm('contest/add', $data)
                    .then(
                        function successCallback(data) {
                            if (data.ResponseCode == 200) {
                                // $scope.Contests = data.Data;
                                $scope.CreateContestForm = {};
                                $scope.closePopup('create_contest');
                                $scope.submitted = false;
                                $scope.getContests();
                            } else {
                                $scope.data.noRecords = true;
                            }
                            if (data.ResponseCode == 500) {
                                var toast = toastr.warning(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                                $scope.data.noRecords = true;
                            }
                            if (data.ResponseCode == 501) {
                                var toast = toastr.warning(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                                $scope.data.noRecords = true;
                            }
                        },
                        function errorCallback(data) {

                            if (typeof data == 'object') {
                                var toast = toastr.error(data.Message, {
                                    closeButton: true
                                });
                                toastr.refreshTimer(toast, 5000);
                                $scope.data.noRecords = true;
                            }
                        });

            }
        }
    }
}]);