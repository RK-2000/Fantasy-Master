'use strict';
app.controller('leagueController',['$scope','$rootScope','$location','environment','$localStorage','$sessionStorage','appDB','toastr','Upload',function($scope,$rootScope,$location,environment,$localStorage,$sessionStorage,appDB,toastr,Upload){
  $scope.env = environment;
  /*
    Description : To get user team details on ground
  */

  $scope.ViewTeamOnGround = function(UserTeamGUID) {
      var $data = {};

      $scope.TeamPlayers = []; //user team list array
      $data.SessionKey = $sessionStorage.user_details.SessionKey; //user session key
      $data.UserTeamGUID = UserTeamGUID; //User Team GUID
      $data.MatchGUID = getQueryStringValue('MatchGUID'); //Match GUID
      $data.Params = "PlayerGUID,PlayerName,PlayerCountry,PlayerPosition,PlayerRole,UserTeamPlayers";

      appDB
          .callPostForm('contest/getUserTeams', $data)
          .then(
              function successCallback(data) {
                  if (data.ResponseCode == 200) {
                    $scope.TeamPlayers = data.Data;
                    $scope.teamStructure = {
                        "WicketKeeper": {
                            "min": 1,
                            "max": 1,
                            "occupied": 0,
                            player: [],
                            "icon": "flaticon1-pair-of-gloves"
                        },
                        "Batsman": {
                            "min": 3,
                            "max": 5,
                            "occupied": 0,
                            player: [],
                            "icon": "flaticon1-ball"
                        },
                        "Bowler": {
                            "min": 3,
                            "max": 5,
                            "occupied": 0,
                            player: [],
                            "icon": "flaticon1-tennis-ball"
                        },
                        "AllRounder": {
                            "min": 1,
                            "max": 3,
                            "occupied": 0,
                            player: [],
                            "icon": "flaticon1-ball"
                        },
                        "Extra": {
                            "min": 3,
                            "max": 3,
                            occupied: 0,
                            player: []
                        },
                        "ready": false
                    };
                    angular.forEach($scope.TeamPlayers.UserTeamPlayers, function(value, key) {
                        if (value.PlayerRole == 'WicketKeeper') {

                            $scope.teamStructure['WicketKeeper'].player.push({
                                'PlayerGUID': value.PlayerGUID,
                                'PlayerPosition': value.PlayerPosition,
                                'PlayerName': value.PlayerName,
                                'Points' : value.Points,
                                'PlayerPic' : value.PlayerPic
                            });
                            $scope.teamStructure['WicketKeeper'].occupied++;
                        }
                        if (value.PlayerRole == 'Batsman') {
                            $scope.teamStructure['Batsman'].player.push({
                                'PlayerGUID': value.PlayerGUID,
                                'PlayerPosition': value.PlayerPosition,
                                'PlayerName': value.PlayerName,
                                'Points' : value.Points,
                                'PlayerPic' : value.PlayerPic
                            });
                            $scope.teamStructure['Batsman'].occupied++;
                        }
                        if (value.PlayerRole == 'AllRounder') {
                            $scope.teamStructure['AllRounder'].player.push({
                                'PlayerGUID': value.PlayerGUID,
                                'PlayerPosition': value.PlayerPosition,
                                'PlayerName': value.PlayerName,
                                'Points' : value.Points,
                                'PlayerPic' : value.PlayerPic
                            });
                            $scope.teamStructure['AllRounder'].occupied++;
                        }
                        if (value.PlayerRole == 'Bowler') {
                            $scope.teamStructure['Bowler'].player.push({
                                'PlayerGUID': value.PlayerGUID,
                                'PlayerPosition': value.PlayerPosition,
                                'PlayerName': value.PlayerName,
                                'Points' : value.Points,
                                'PlayerPic' : value.PlayerPic
                            });
                            $scope.teamStructure['Bowler'].occupied++;
                        }
                    });
                }else {
                  $scope.data.noRecords = true;
                }
                if (data.ResponseCode == 500) {
                    var toast = toastr.warning(data.Message, {
                        closeButton: true
                    });
                    toastr.refreshTimer(toast, 5000);
                    $scope.data.noRecords = true;
                }
                if (data.ResponseCode == 501) {
                    var toast = toastr.warning(data.Message, {
                        closeButton: true
                    });
                    toastr.refreshTimer(toast, 5000);
                    $scope.data.noRecords = true;
                }
              },
              function errorCallback(data) {
                if (typeof data == 'object') {
                    var toast = toastr.error(data.Message, {
                        closeButton: true
                    });
                    toastr.refreshTimer(toast, 5000);
                    $scope.data.noRecords = true;
                }
              });
  }

  /*Funcion to get joined user teams*/
  $scope.userTeams = [];
  $scope.getUserTeam = function(){
    var $data = {};

      $scope.TeamPlayers = []; //user team list array
      $data.SessionKey = $sessionStorage.user_details.SessionKey; //user session key
      $data.MatchGUID = getQueryStringValue('MatchGUID'); //Match GUID
      $data.ContestGUID = getQueryStringValue('League'); //Contest GUID
      $data.Params = 'UserTeamName,TotalPoints,UserWinningAmount,FirstName,UserRank,Username,UserGUID';

      appDB
          .callPostForm('contest/getJoinedContestsUsers', $data)
          .then(
              function successCallback(data) {
                  if (data.ResponseCode == 200) {
                   $scope.userTeams = data.Data; 
                   angular.forEach($scope.userTeams.Records, function(value,key){
                      if(value.UserGUID == $sessionStorage.user_details.UserGUID){
                        $scope.ViewTeamOnGround(value.UserTeamGUID);
                      }
                   });
                }else {
                  $scope.data.noRecords = true;
                }
                if (data.ResponseCode == 500) {
                    var toast = toastr.warning(data.Message, {
                        closeButton: true
                    });
                    toastr.refreshTimer(toast, 5000);
                    $scope.data.noRecords = true;
                }
                if (data.ResponseCode == 501) {
                    var toast = toastr.warning(data.Message, {
                        closeButton: true
                    });
                    toastr.refreshTimer(toast, 5000);
                    $scope.data.noRecords = true;
                }
              },
              function errorCallback(data) {
                if (typeof data == 'object') {
                    var toast = toastr.error(data.Message, {
                        closeButton: true
                    });
                    toastr.refreshTimer(toast, 5000);
                    $scope.data.noRecords = true;
                }
              });
  }

  /*function to get contests according to matches*/
  $scope.Contest = [];
  $scope.getContests = function() {
      var $data = {};
      $data.MatchGUID = getQueryStringValue('MatchGUID'); // Selected MatchGUID
      $data.ContestGUID = getQueryStringValue('League'); // Selected ContestGUID
      $data.SessionKey = $sessionStorage.user_details.SessionKey; // User SessionKey
      $data.PageNo = 0; // Page Number
      $data.PageSize    = $scope.data.pageSize; // Page Size
      $data.SessionKey = $sessionStorage.user_details.SessionKey; // User SessionKey
      $data.Params = 'Privacy,IsPaid,WinningAmount,ContestSize,EntryFee,NoOfWinners,EntryType,IsJoined,Status,ContestFormat,ContestType,CustomizeWinning,TotalJoined,UserInvitationCode,SeriesName,MatchType,MatchNo,MatchStartDateTime,TeamNameLocal,TeamNameVisitor,TeamNameShortLocal,TeamNameShortVisitor,TeamFlagLocal,TeamFlagVisitor,MatchLocation,SeriesGUID,Status,MatchScoreDetails';
      $data.Keyword = $scope.Keyword;

      appDB
          .callPostForm('contest/getContest', $data)
          .then(
            function successCallback(data) {
              if (data.ResponseCode == 200) {
                $scope.Contest = data.Data;
                $scope.getUserTeam();
              } else {
                  $scope.data.noRecords = true;
              }
              if (data.ResponseCode == 500) {
                  var toast = toastr.warning(data.Message, {
                      closeButton: true
                  });
                  toastr.refreshTimer(toast, 5000);
                  $scope.data.noRecords = true;
              }
              if (data.ResponseCode == 501) {
                  var toast = toastr.warning(data.Message, {
                      closeButton: true
                  });
                  toastr.refreshTimer(toast, 5000);
                  $scope.data.noRecords = true;
              }
            },
            function errorCallback(data) {
              if (typeof data == 'object') {
                  var toast = toastr.error(data.Message, {
                      closeButton: true
                  });
                  toastr.refreshTimer(toast, 5000);
                  $scope.data.noRecords = true;
              }
            });
      $scope.data.listLoading = false;
  }
  
  
  

  $scope.pointSystem  = function(){
    $scope.points  = [];
    var $data      = {};
    $data.StatusID = 1;
    appDB
      .callPostForm('sports/getPoints',$data) 
      .then(
          function successCallback(data)
          { 
              if(data.ResponseCode == 200)
              { 
                $scope.points = data.Data.Records;
                $scope.Contest.MatchType = 'Womens ODI';
                $rootScope.pointsArray = [];
                if($scope.Contest.MatchType.includes('T20')){
                  angular.forEach($scope.points,function(value,key){
                      $rootScope.pointsArray.push({'PointsTypeDescprition':value.PointsTypeDescprition,'Points' : value.PointsT20,'PointsType':value.PointsType,'PointsInningType':value.PointsInningType});
                  });
                }
                if($scope.Contest.MatchType.includes('ODI')){
                  angular.forEach($scope.points,function(value,key){
                      $rootScope.pointsArray.push({'PointsTypeDescprition':value.PointsTypeDescprition,'Points' : value.PointsODI,'PointsType':value.PointsType,'PointsInningType':value.PointsInningType});
                  });
                }
                if($scope.Contest.MatchType.includes('Test')){
                  angular.forEach($scope.points,function(value,key){
                      $rootScope.pointsArray.push({'PointsTypeDescprition':value.PointsTypeDescprition,'Points' : value.PointsTEST,'PointsType':value.PointsType,'PointsInningType':value.PointsInningType});
                  });
                }
                console.log($rootScope.pointsArray);
              }
              if(data.ResponseCode == 500){
                var toast =   toastr.warning(data.Message, {
                                closeButton: true
                              });
                toastr.refreshTimer(toast, 5000);

              }
              if(data.ResponseCode == 501){
                var toast =   toastr.warning(data.Message, {
                                closeButton: true
                              });
                toastr.refreshTimer(toast, 5000);
              }
          },
          function errorCallback(data)
          { 
            
            if(typeof data == 'object')
            {
              var toast =  toastr.error(data.Message, {
                closeButton: true
              });
              toastr.refreshTimer(toast, 5000);
            }
      });    
  }



  $scope.fantasyScoreCard  = function(){
    $rootScope.fantasyScores  = [];
    var $data       = {};
    $data.MatchGUID = getQueryStringValue('MatchGUID');
    $data.Params = 'PlayerRole,PlayerPic,PlayerCountry,PlayerBornPlace,PlayerBattingStyle,PlayerBowlingStyle,MatchType,MatchNo,MatchDateTime,SeriesName,TeamGUID,PlayerBattingStats,PlayerBowlingStats,IsPlaying,PointsData,TotalPoints';
    appDB
      .callPostForm('sports/getPlayers',$data) 
      .then(
          function successCallback(data)
          { 
              if(data.ResponseCode == 200)
              { 
                $rootScope.fantasyScores = data.Data;
              }
              if(data.ResponseCode == 500){
                var toast =   toastr.warning(data.Message, {
                                closeButton: true
                              });
                toastr.refreshTimer(toast, 5000);

              }
              if(data.ResponseCode == 501){
                var toast =   toastr.warning(data.Message, {
                                closeButton: true
                              });
                toastr.refreshTimer(toast, 5000);
              }
          },
          function errorCallback(data)
          { 
            
            if(typeof data == 'object')
            {
              var toast =  toastr.error(data.Message, {
                closeButton: true
              });
              toastr.refreshTimer(toast, 5000);
            }
      });    
  }

  $scope.fantasyScoreCard();

}]);
