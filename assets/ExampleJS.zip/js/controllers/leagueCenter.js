'use strict';

app.controller('LeagueCenterController',['$scope','$rootScope','$location','environment','$localStorage','$sessionStorage','appDB','toastr',function($scope,$rootScope,$location,environment,$localStorage,$sessionStorage,appDB,toastr){
  $scope.env = environment;
  if($sessionStorage.hasOwnProperty('user_details') && $sessionStorage.isLoggedIn==true){
  	$scope.user_details = $sessionStorage.user_details;
  	$scope.isLoggedIn = $sessionStorage.isLoggedIn;
    $scope.base_url = base_url;

    $scope.activeTab = 'upcoming';
    $scope.activeMenuTab = function(tab){
      $scope.activeTab = tab;
    }

    /*function to get joined match Status*/
    $scope.ContestDetails = [];
    $scope.LeagueCenter = function(Status){

      var $data = {};
      $data.SessionKey = $sessionStorage.user_details.SessionKey; //user session key
      $data.MatchGUID = ''; //Match GUID
      $data.Params = 'Privacy,IsPaid,WinningAmount,ContestSize,EntryFee,NoOfWinners,EntryType,Status,SeriesName,MatchNo,MatchStartDateTime,TeamNameLocal,TeamNameVisitor,TeamNameShortLocal,TeamNameShortVisitor,TeamFlagLocal,TeamFlagVisitor,MatchLocation,MatchGUID';
      $data.PageNo = 0;
      $data.StatusID = Status;
      $data.Keyword = $scope.Keyword;
      appDB
      .callPostForm('contest/getJoinedContests',$data) 
      .then(
          function successCallback(data)
          { 
              
              if(data.ResponseCode == 200)
              { 
                // if(data.Data.Records){
                  $scope.ContestDetails = data.Data;
                // }else{
                  // $scope.ContestDetails = [];
                // }
              }
              if(data.ResponseCode == 500){
                var toast =  toastr.warning(data.Message, {
                    closeButton: true
                });
                toastr.refreshTimer(toast, 5000);

              }
              if(data.ResponseCode == 501){
                var toast =  toastr.warning(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);
              }
          },
          function errorCallback(data)
          { 
            
            if(typeof data == 'object')
            {
                var toast =  toastr.error(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);
            }
      });  

    }    

  }


}]);
