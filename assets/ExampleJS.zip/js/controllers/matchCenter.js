'use strict';

app.controller('matchCenterController',['$scope','$rootScope','$location','environment','$localStorage','$sessionStorage','appDB','toastr','$filter',function($scope,$rootScope,$location,environment,$localStorage,$sessionStorage,appDB,toastr,$filter){
  $scope.env = environment;
  $scope.coreLogic = Mobiweb.helpers;
  if($sessionStorage.hasOwnProperty('user_details') && $sessionStorage.isLoggedIn==true){
  	$scope.user_details = $sessionStorage.user_details;
	 
  	/*Function to get all series*/
  	$scope.seriesList = [];
  	$scope.Series = function(){
  		var $data = {};
      $data.Params='SeriesName,SeriesGUID,StatusID,SeriesStartDate';
      $data.OrderBy='SeriesStartDate';
      $data.Sequence='ASC';
      $data.StatusID=2;
      // $data.SeriesEndDate= $filter('date')(new Date(), 'yyyy-MM-dd');
  	  appDB
    	.callPostForm('sports/getSeries',$data) 
    	.then(
    		function successCallback(data)
    		{ 

    			if(data.ResponseCode == 200)
    			{ 
					 $scope.seriesList = data.Data;
					 $scope.getMatches('');
				  }
  		  	if(data.ResponseCode == 500){
    				var toast =  toastr.warning(data.Message, {
    					closeButton: true
    				});
    				toastr.refreshTimer(toast, 5000);
		      }
    			if(data.ResponseCode == 501){
    				var toast =  toastr.warning(data.Message, {
    					closeButton: true
    				});
    				toastr.refreshTimer(toast, 5000);
    			}
    		},
    		function errorCallback(data)
    		{ 
          if(typeof data == 'object')
    			{
    				var toast =  toastr.error(data.Message, {
    					closeButton: true
    				});
    				toastr.refreshTimer(toast, 5000);
    			}
    		});  
  	}
  	$scope.Series();

  	/*Function to get matches*/
	  $scope.MatchesList = [];
    $scope.getMatches = function(SelectedSeries){
      var $data = {};
      $data.SeriesGUID = SelectedSeries; // Selected series ID
      $localStorage.SeriesGUID = SelectedSeries;
      if(!SelectedSeries){
        $data.Filter ='Today';
      }
      $data.Params        = 'SeriesName,MatchType,MatchNo,MatchStartDateTime,TeamNameLocal,TeamNameVisitor,TeamNameShortLocal,TeamNameShortVisitor,TeamFlagLocal,TeamFlagVisitor,MatchLocation,Status,StatusID';
      $data.Status        = 'Pending';
  	  $data.StatusID      = 1;
    	appDB
    	.callPostForm('sports/getMatches',$data) 
    	.then(
    		function successCallback(data)
    		{ 
          if(data.ResponseCode == 200)
    			{ 
					 $scope.MatchesList = data.Data;
           if(!SelectedSeries && data.Data.length <= 0){
              $scope.ErrorMessage = 'There is not matches available for today.'
           }
           else{
              $scope.ErrorMessage = 'Matches not available for this series.'
           }
				  }
    			if(data.ResponseCode == 500){
    				var toast =  toastr.warning(data.Message, {
    					closeButton: true
    				});
    				toastr.refreshTimer(toast, 5000);
				  }
    			if(data.ResponseCode == 501){
    				var toast =  toastr.warning(data.Message, {
    					closeButton: true
    				});
    				toastr.refreshTimer(toast, 5000);
    			}
    		},
    		function errorCallback(data)
    		{ 

    			if(typeof data == 'object')
    			{
    				var toast =  toastr.error(data.Message, {
    					closeButton: true
    				});
    				toastr.refreshTimer(toast, 5000);
    			}
    		});  
  	}
  }
  else{
  
  	window.location.href = base_url;
  }
}]);
