'use strict';
app.controller('profileController',['$scope','$rootScope','$location','environment','$localStorage','$sessionStorage','appDB','toastr','Upload',function($scope,$rootScope,$location,environment,$localStorage,$sessionStorage,appDB,toastr,Upload){
  $scope.env = environment;

  if($sessionStorage.hasOwnProperty('user_details') && $sessionStorage.isLoggedIn==true){
  	$scope.user_details = $sessionStorage.user_details;
  	$scope.isLoggedIn = $sessionStorage.isLoggedIn;
    

    /*function to get profile details*/
    $scope.profileDetails = {};
    $scope.getProfileInfo = function(){
    	
    	var $data = {};
    	$data.UserGUID   = $sessionStorage.user_details.UserGUID;
    	$data.SessionKey = $sessionStorage.user_details.SessionKey;
    	$data.Params     = 'UserTypeID,UserTypeName,FirstName, MiddleName, LastName, Email, Username, Gender, BirthDate, CountryCode, CountryName, CityName, StateName, PhoneNumber,Address,ReferralCode,ProfilePic,TotalCash';
    	appDB
      .callPostForm('users/getProfile',$data) 
      .then(
        	function successCallback(data)
        	{ 
              
              if(data.ResponseCode == 200)
              { 

                  $scope.profileDetails = data.Data;
                  
              }
              if(data.ResponseCode == 500){
              	var toast =  toastr.warning(data.Message, {
  				  	closeButton: true
  				});
  				toastr.refreshTimer(toast, 5000);

              }
              if(data.ResponseCode == 501){
              	var toast =  toastr.warning(data.Message, {
  				  	closeButton: true
  				});
  				toastr.refreshTimer(toast, 5000);
              }
        	},
        	function errorCallback(data)
        	{ 
          	
          	if(typeof data == 'object')
          	{
            		var toast =  toastr.error(data.Message, {
  				  	closeButton: true
  				});
  				toastr.refreshTimer(toast, 5000);
          	}
    	});  

    }
    /*function to update profile details*/

    $scope.submitted = false;
    $scope.updateProfile = function(form){
      var $data = {};
      $scope.helpers = Mobiweb.helpers;
      $scope.submitted = true; 
      if(!form.$valid)
      {
        return false;
      }
      $data = {
                FirstName     : $scope.profileDetails.FirstName,
                BirthDate     : $scope.profileDetails.BirthDate,
                Gender        : $scope.profileDetails.Gender,
                CountryCode   : $scope.profileDetails.CountryCode,
                StateName     : $scope.profileDetails.StateName,
                CityName      : $scope.profileDetails.CityName,
                Address       : $scope.profileDetails.Address,
                SessionKey    : $sessionStorage.user_details.SessionKey
              };
      
      appDB
      .callPostForm('users/updateUserInfo',$data) 
      .then(
          function successCallback(data)
          { 
              if(data.ResponseCode == 200)
              { 

                  $scope.profileDetails = data.Data;
                  $scope.getProfileInfo();
                  $scope.submitted = false;
                  var toast =  toastr.success(data.Message, {
                      closeButton: true
                  });
                  toastr.refreshTimer(toast, 5000);
              }
              if(data.ResponseCode == 500){
                var toast =  toastr.warning(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);

              }
              if(data.ResponseCode == 501){
                var toast =  toastr.warning(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);
              }
          },
          function errorCallback(data)
          { 
            
            if(typeof data == 'object')
            {
              var toast =  toastr.error(data.Message, {
                closeButton: true
              });
              toastr.refreshTimer(toast, 5000);
            }
      });    
    }

    /*change password*/
    $scope.updatePassword=[];
    $scope.changePassword = function(createform1){  
            $scope.helpers = Mobiweb.helpers;
     $scope.updateMsg = false;
        $scope.isSubmitted = true;
        if(!createform1.$valid)
        {
          return false;
        }
      var data={};
      $scope.errorMsg="";
      $scope.showMsg=false; 
      data.SessionKey=$sessionStorage.user_details.SessionKey;
      data.CurrentPassword=$scope.CurrentPassword;
      data.Password=$scope.Password;
      
      $scope.isSubmitted = true;
      appDB
      .callPostForm('users/changePassword',data) 
      .then(
        function success(data){ 
          if(data.ResponseCode==200){ 
            $scope.updatePassword = data.response;  
            var toast =  toastr.success(data.Message, {
                closeButton: true
              });
            toastr.refreshTimer(toast, 5000);
          }

          if(data.ResponseCode==500){ 
            var toast =  toastr.warning(data.Message, {
                closeButton: true
              });
            toastr.refreshTimer(toast, 5000);
          }
          if(data.ResponseCode==501){ 
            var toast =  toastr.error(data.Message, {
                closeButton: true
              });
            toastr.refreshTimer(toast, 5000);
          } 
        },
        function error(data){ 
          var toast =  toastr.error(data.Message, {
                closeButton: true
              });
            toastr.refreshTimer(toast, 5000);    
        }
      );
    }

    /*update profile image*/
    $scope.$watch('picFile', function (files,old) {
      
      $scope.formUpload = false;
      if (files != null) {
        var elem = document.getElementById("myBar"); 
        var width = 1;
        var id = setInterval(frame, 10);
        
        $('#myProgress').css('display','block');
        function frame() {
          if (width >= 100) {
            clearInterval(id);
          } else {
            width++; 
            elem.style.width = width + '%'; 
          }
        }

       var fd = new FormData();
       fd.append('SessionKey',$sessionStorage.user_details.SessionKey);
       fd.append('File', files);
       fd.append('Section', 'ProfilePic');
       fd.append('Caption', 'Profile Pic');
       appDB
       .callPostImage('upload/image',fd) 
       .then(
          function success(data){ 
           
           if(data.ResponseCode == 200 ){ 
              $('#myProgress').css('display','none');
              $sessionStorage.user_details.ProfilePic = data.Data.MediaURL;
              $scope.getProfileInfo();
            } 
          },
          function error(data){ 
           $scope.errorMsg = data.message; 
          }
        );

      }
      });
      
      /*function to get country list*/
    $scope.countryList = [];
    $scope.getCountryList = function(){
      
      var $data = {};
      appDB
      .callPostForm('utilities/getCountries',$data) 
      .then(
          function successCallback(data)
          { 
              
              if(data.ResponseCode == 200)
              { 

                  $scope.countryList = data.Data;
                  
              }
              if(data.ResponseCode == 500){
                var toast =  toastr.warning(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);

              }
              if(data.ResponseCode == 501){
                var toast =  toastr.warning(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);
              }
          },
          function errorCallback(data)
          { 
            
            if(typeof data == 'object')
            {
                var toast =  toastr.error(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);
            }
      }); 
    }

    /*remove profile pic*/
    $scope.removeProfilePic = function(){
      var $data = {};
      $data.SessionKey  = $sessionStorage.user_details.SessionKey;
      $data.MediaGUID   = '';
      appDB
      .callPostForm('upload/delete',$data) 
      .then(
          function successCallback(data)
          { 
              
              if(data.ResponseCode == 200)
              { 
                var toast =  toastr.success(data.Message, {
                  closeButton: true
                });
                toastr.refreshTimer(toast, 5000);
                  
              }
              if(data.ResponseCode == 500){
                var toast =  toastr.warning(data.Message, {
                  closeButton: true
                });
                toastr.refreshTimer(toast, 5000);

              }
              if(data.ResponseCode == 501){
                var toast =  toastr.warning(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);
              }
          },
          function errorCallback(data)
          { 
            
            if(typeof data == 'object')
            {
                var toast =  toastr.error(data.Message, {
              closeButton: true
          });
          toastr.refreshTimer(toast, 5000);
            }
      }); 
    }
  }
  else{
    window.location.href = base_url;
  }
  
}]);
