/*global angular*/

(function (angular) {
  'use strict';

  angular.module('720kb', [
    'ngRoute',
    'ui.bootstrap',
    '720kb.datepicker'
  ]);
}(angular));
