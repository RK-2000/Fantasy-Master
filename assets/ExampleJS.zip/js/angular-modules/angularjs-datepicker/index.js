/*global module, require*/
(function setUp(module, require) {
  'use strict';

  require('./dist/angular-datepicker');

  module.exports = '720kb.datepicker';
}(module, require));
